# Ride the Line: Morro Solar — Milestone 1

Descenso POV de MTB en navegador (Vite + Three.js). Este milestone incluye trail 3D descendente, cámara tipo GoPro, manubrio visible, steering A/D, terreno árido y rocoso, y océano al fondo.
Todavía **no** incluye roost, crashes, scoring ni salto.

## Ejecutar

```bash
npm install
npm run dev        # abre http://localhost:5173
```

Build de producción: `npm run build` → carpeta `dist/`.

## Controles

| Tecla | Acción |
|---|---|
| A / ← · D / → | dirección |
| S / ↓ | freno |
| Enter / click | drop in |
| R | reiniciar |
| M | sonido on/off |
| G | panel de ajustes en vivo + debug |

URL útiles: `?q=low` (sin sombras ni antialias) · `?s=250` (arranca en ese metro del trail) · `?gui` (abre el panel).

## Dónde se ajusta el feeling

Todo está en **`src/config.js`**, comentado. Resumen:

| Qué | Parámetro |
|---|---|
| Ancho del trail | `trail.widthScale` (global) · `sections[].width` (por sección) |
| Pendiente | `trail.startElevation` / `trail.endElevation` (desnivel total) · `sections[].grade` (reparto entre secciones) |
| Velocidad | `bike.gravityScale`, `bike.dragCoef` (vel. tope), `bike.maxSpeed`, `bike.startSpeed`, `bike.minSpeed` |
| Intensidad de curvas | `trail.curveIntensity` (global) · `sections[].path` (ángulo y radio de cada curva) |
| Altura de cámara | `camera.height` (+ `camera.tiltDeg`, `camera.forwardOffset`) |
| FOV | `camera.fov`, `camera.fovHighSpeed`, `camera.fovSpeedRef` |
| Longitud del recorrido | `trail.lengthScale` (+ rectas en `sections[].path`) |

Al cargar, la consola muestra una tabla con largo, pendiente real y desnivel de cada sección.

## Estructura

```
src/
  main.js · config.js · styles.css
  game/
    Game.js            loop, escena, panel de ajustes
    TrailGenerator.js  spline del trail por secciones (curvatura, pendiente, ancho)
    Terrain.js         cerro, tallado del sendero, malla, rocas instanciadas
    Environment.js     cielo de Lima, niebla, luces, océano, ciudad, cruz/antena
    BikeController.js  física: gravedad, freno, steering con inercia
    BikeModel.js       manubrio, guantes, antebrazos, horquilla, rueda
    CameraRig.js       POV: suspensión, vibración, lean, look-ahead, FOV
    FXSystem.js        polvo suspendido (parallax de velocidad)
    AudioSystem.js     viento + rodadura + gravilla (procedural, placeholder)
    GameState.js       intro → riding → finished
    input/KeyboardInput.js   fuente de input intercambiable (futuro: giroscopio)
  ui/HUD.js
  utils/noise.js · utils/textures.js
```

`BikeController` sólo lee `{ steer, brake, drift, pop }` desde una fuente de input. Para usar el celular como manubrio basta con crear otra fuente con el mismo `read()`.
