// ============================================================================
//  RIDE THE LINE: MORRO SOLAR — PARÁMETROS DE AJUSTE (Milestone 1)
// ----------------------------------------------------------------------------
//  Todo lo que define el "feeling" del descenso está aquí.
//  Unidades: metros, segundos, grados (salvo que se indique otra cosa).
//  Varios valores también se pueden tocar en vivo con el panel de debug (tecla G).
// ============================================================================

export const CONFIG = {
  // Semilla: misma semilla = mismo terreno, rocas y micro-relieve.
  seed: 29,

  // --------------------------------------------------------------------------
  //  TRAIL
  // --------------------------------------------------------------------------
  trail: {
    // PENDIENTE (global): el trail baja de startElevation a endElevation.
    // Más diferencia = más pendiente media = más velocidad.
    startElevation: 115,
    endElevation: 35,

    // LONGITUD DEL RECORRIDO: multiplica rectas y radios de todas las secciones.
    // 1.0 ≈ 415 m ≈ 40 s · 1.15 ≈ 480 m ≈ 47 s · 1.4 ≈ 580 m ≈ 57 s
    lengthScale: 1.15,

    // INTENSIDAD DE CURVAS: multiplica el ángulo de todas las curvas.
    // 0 = recta, 1 = diseño original, 1.3 = zetas más cerradas.
    curveIntensity: 1.0,

    // ANCHO DEL TRAIL: multiplica el ancho de cada sección (abajo).
    widthScale: 1.0,

    // Suavizado de la transición entre recta y curva (metros). Más alto = curvas más fluidas.
    curvatureSmoothing: 6,

    // Metros extra al final para frenar tras la meta.
    runoutLength: 45,

    // Secciones del prompt maestro. Cada una tiene:
    //   width      ancho del sendero en metros (antes de widthScale)
    //   grade      PENDIENTE RELATIVA de la sección. Se reescala para que el total
    //              cumpla start/endElevation, así que lo que importa es la proporción
    //              entre secciones (p.ej. Fast = 0.24 es ~2x más empinada que Drop In = 0.12).
    //   roughness  0–1: baches, vibración y micro-relieve de la superficie.
    //   exposure   [izq, der] qué tan rápido cae el cerro a cada lado (sensación de borde).
    //   rockDensity multiplicador de rocas laterales.
    //   path       ['S', metros] = recta · ['T', grados, radio] = curva (+ derecha, − izquierda)
    sections: [
      {
        id: 'dropin', name: 'Drop In',
        width: 1.7, grade: 0.12, roughness: 0.35, exposure: [1.6, 0.8], rockDensity: 0.8,
        path: [['S', 14], ['T', 16, 45], ['S', 10], ['T', -24, 38], ['S', 8]],
      },
      {
        id: 'zetas', name: 'Zetas',
        width: 1.25, grade: 0.13, roughness: 0.5, exposure: [1.0, 1.0], rockDensity: 1.5,
        path: [['S', 4], ['T', -62, 11], ['S', 12], ['T', 128, 7], ['S', 12], ['T', -128, 7],
               ['S', 10], ['T', 62, 12], ['S', 6]],
      },
      {
        id: 'technical', name: 'Technical Line',
        width: 1.5, grade: 0.15, roughness: 0.75, exposure: [0.9, 1.3], rockDensity: 1.3,
        path: [['S', 10], ['T', 24, 30], ['S', 14], ['T', -34, 26], ['S', 12], ['T', 14, 40]],
      },
      {
        id: 'fast', name: 'Fast Section',
        width: 1.9, grade: 0.24, roughness: 0.45, exposure: [2.2, 0.9], rockDensity: 1.0,
        path: [['S', 22], ['T', -18, 70], ['S', 24], ['T', 26, 60], ['S', 22]],
      },
      {
        id: 'final', name: 'Final',
        width: 2.0, grade: 0.11, roughness: 0.35, exposure: [1.2, 1.2], rockDensity: 0.8,
        path: [['S', 20], ['T', -12, 80], ['S', 28]],
      },
    ],
  },

  // --------------------------------------------------------------------------
  //  TERRENO
  // --------------------------------------------------------------------------
  terrain: {
    innerCell: 0.9,        // resolución (m) cerca del trail. Menor = más detalle, más costo.
    innerMargin: 70,       // metros de terreno detallado alrededor del trail
    outerExtent: 2600,     // hasta dónde llega el terreno lejano
    ridgeFalloff: 0.16,    // caída lineal del cerro a los lados del trail
    ridgeFalloffQuad: 0.0045, // caída cuadrática (hace que el cerro "se desplome" al mar)
    bankWidth: 1.3,        // ancho del hombro entre trail y ladera
    rockCount: 1.0,        // multiplicador global de rocas
  },

  // --------------------------------------------------------------------------
  //  BICICLETA / VELOCIDAD
  // --------------------------------------------------------------------------
  bike: {
    gravityScale: 1.0,     // VELOCIDAD: cuánto acelera la pendiente (1 = gravedad real)
    dragCoef: 0.0105,      // resistencia del aire: define la velocidad tope en cada pendiente
    rollResistance: 0.16,  // m/s² de fricción constante
    startSpeed: 3.5,       // m/s al dropear
    minSpeed: 3.0,         // nunca bajas de esto (sin pedaleo en este milestone)
    maxSpeed: 17.0,        // m/s (≈ 61 km/h)
    brakeDecel: 6.0,       // m/s² con S

    // Steering
    steerResponse: 5.0,    // qué tan rápido responde el input (progresivo, no instantáneo)
    maxYawRate: 1.8,       // rad/s de giro a baja velocidad
    yawSpeedRef: 7.0,      // a mayor velocidad, menos giro: maxYaw / (1 + v/yawSpeedRef)
    yawInertia: 6.0,       // inercia rotacional de la bici
    trailAssist: 0.8,     // 0–1: cuánto sigue la bici la curva sola. 1 = automático, 0 = todo manual
    alignAssist: 2.5,      // tendencia a enderezarse al soltar la tecla (como seguir la huella)
    edgeAssist: 1.6,       // empujón suave hacia el centro cuando te sales
    cornerAssist: 0.8,     // 0–1: frena solo antes de curvas muy cerradas (hasta que existan crashes)
    cornerGrip: 0.85,      // agarre lateral (g) para el cálculo de velocidad en curva
    offTrailDrag: 2.2,     // m/s² extra de frenado fuera del sendero
    maxOffset: 2.6,        // metros fuera del borde antes de un "muro" suave
  },

  // --------------------------------------------------------------------------
  //  CÁMARA POV (GoPro en casco)
  // --------------------------------------------------------------------------
  camera: {
    height: 1.58,          // ALTURA DE CÁMARA sobre el suelo (m)
    forwardOffset: -0.02,  // + adelante / − atrás respecto al eje del pedalier
    tiltDeg: -13,          // inclinación hacia abajo del casco
    fov: 70,               // FOV vertical normal
    fovHighSpeed: 78,      // FOV a velocidad alta
    fovSpeedRef: 15,       // m/s en que se alcanza fovHighSpeed
    leanFactor: 0.38,      // cuánto se inclina la cámara en curvas (0 = nada)
    lookAhead: 7,          // metros hacia adelante para anticipar la pendiente
    lookAheadWeight: 0.45, // cuánto la mirada sigue la pendiente que viene
    shake: 1.0,            // intensidad de micro-vibración
    headDamping: 9.0,      // suavizado de cabeza (piernas absorben). Menor = más flotante
  },

  // --------------------------------------------------------------------------
  //  MANUBRIO / BICI VISIBLE
  // --------------------------------------------------------------------------
  cockpit: {
    barWidth: 0.78,        // ancho de manubrio (m)
    barForward: 0.56,      // distancia horizontal cabeza → manubrio
    barHeight: 1.03,       // altura del manubrio sobre el suelo
    showArms: true,
  },

  fx: {
    speedParticles: 260,
    audio: true,
  },
};
