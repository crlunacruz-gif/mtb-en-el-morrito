/**
 * Audio procedural (placeholders) preparado por capas:
 *   wind     — viento, crece con la velocidad²
 *   rolling  — rueda sobre tierra (grave), crece con velocidad y rugosidad
 *   gravel   — crujido de piedra suelta (agudo, granular)
 * Capas futuras (roost/skid, landing, suspensión) se agregan con addLayer().
 * Se inicia tras la primera interacción del usuario (política de autoplay).
 */
export class AudioSystem {
  constructor(enabled = true) {
    this.enabled = enabled;
    this.ctx = null;
    this.layers = {};
    this.muted = false;
  }

  start() {
    if (!this.enabled || this.ctx) return;
    const AC = window.AudioContext || window.webkitAudioContext;
    if (!AC) return;
    const ctx = new AC();
    this.ctx = ctx;
    this.master = ctx.createGain();
    this.master.gain.value = 0.7;
    this.master.connect(ctx.destination);

    const noise = this.makeNoiseBuffer(3);
    this.layers.wind = this.addLayer(noise, 'bandpass', 700, 0.6);
    this.layers.rolling = this.addLayer(noise, 'lowpass', 160, 1);
    this.layers.gravel = this.addLayer(noise, 'highpass', 2600, 1);
  }

  makeNoiseBuffer(seconds) {
    const ctx = this.ctx;
    const buf = ctx.createBuffer(1, ctx.sampleRate * seconds, ctx.sampleRate);
    const d = buf.getChannelData(0);
    let last = 0;
    for (let i = 0; i < d.length; i++) {
      const w = Math.random() * 2 - 1;
      last = (last + 0.02 * w) / 1.02; // ruido café-rosado
      d[i] = last * 3.5 + w * 0.15;
    }
    return buf;
  }

  addLayer(buffer, type, freq, q) {
    const ctx = this.ctx;
    const src = ctx.createBufferSource();
    src.buffer = buffer;
    src.loop = true;
    src.playbackRate.value = 0.8 + Math.random() * 0.4;
    const filter = ctx.createBiquadFilter();
    filter.type = type;
    filter.frequency.value = freq;
    filter.Q.value = q;
    const gain = ctx.createGain();
    gain.gain.value = 0;
    src.connect(filter).connect(gain).connect(this.master);
    src.start();
    return { src, filter, gain };
  }

  toggleMute() {
    this.muted = !this.muted;
    if (this.master) this.master.gain.value = this.muted ? 0 : 0.7;
  }

  update(speed, roughness, onTrail) {
    if (!this.ctx) return;
    const t = this.ctx.currentTime;
    const v = Math.min(1.3, speed / 15);
    const L = this.layers;
    L.wind.gain.gain.setTargetAtTime(0.05 + 0.5 * v * v, t, 0.1);
    L.wind.filter.frequency.setTargetAtTime(400 + 900 * v, t, 0.2);
    L.rolling.gain.gain.setTargetAtTime(Math.min(1, speed / 6) * (0.35 + roughness * 0.5), t, 0.05);
    L.rolling.filter.frequency.setTargetAtTime(90 + 140 * v, t, 0.1);
    const crunch = (onTrail ? 0.05 : 0.2) + roughness * 0.1;
    L.gravel.gain.gain.setTargetAtTime(Math.min(1, speed / 8) * crunch * (0.6 + Math.random() * 0.8), t, 0.02);
  }
}
