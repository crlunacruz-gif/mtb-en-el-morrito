import * as THREE from 'three';

/**
 * Cockpit visible desde el POV: manubrio, puños, guantes, antebrazos,
 * potencia, tubo de dirección, horquilla y rueda delantera.
 * Todo en coordenadas locales de la bici: origen en el suelo bajo el pedalier,
 * −Z hacia adelante, +Y arriba.
 */
export class BikeModel {
  constructor(config) {
    this.cfg = config;
    this.group = new THREE.Group();
    this.group.rotation.order = 'YXZ';
    this.steerPivot = new THREE.Group(); // rota con el manubrio
    this.wheelSpin = new THREE.Group();
    this.build();
  }

  build() {
    const c = this.cfg.cockpit;
    const cam = this.cfg.camera;
    const W = c.barWidth;
    const barZ = -(cam.forwardOffset + c.barForward);
    const barY = c.barHeight;

    const mBlack = new THREE.MeshStandardMaterial({ color: '#1b1c1e', roughness: 0.55, metalness: 0.35 });
    const mRubber = new THREE.MeshStandardMaterial({ color: '#232323', roughness: 0.95 });
    const mFrame = new THREE.MeshStandardMaterial({ color: '#8f2320', roughness: 0.4, metalness: 0.25 });
    const mStanchion = new THREE.MeshStandardMaterial({ color: '#c9a24a', roughness: 0.25, metalness: 0.8 });
    const mLowers = new THREE.MeshStandardMaterial({ color: '#262729', roughness: 0.5, metalness: 0.3 });
    const mAccent = new THREE.MeshStandardMaterial({ color: '#d0621c', roughness: 0.35, metalness: 0.6 });
    const mGlove = new THREE.MeshStandardMaterial({ color: '#2a2b2e', roughness: 0.85 });
    const mGlovePanel = new THREE.MeshStandardMaterial({ color: '#e7e5df', roughness: 0.8 });
    const mSleeve = new THREE.MeshStandardMaterial({ color: '#39414a', roughness: 0.9 });
    const mTire = new THREE.MeshStandardMaterial({ color: '#2b2a28', roughness: 0.95 });
    const mRim = new THREE.MeshStandardMaterial({ color: '#3a3b3d', roughness: 0.4, metalness: 0.7 });
    this.materials = [mBlack, mRubber, mFrame, mStanchion, mLowers, mAccent, mGlove, mGlovePanel, mSleeve, mTire, mRim];

    // Eje de dirección (ángulo de dirección 64°)
    const headAngle = THREE.MathUtils.degToRad(64);
    const axis = new THREE.Vector3(0, -Math.sin(headAngle), -Math.cos(headAngle)); // hacia abajo-adelante
    const stemTop = new THREE.Vector3(0, barY - 0.03, barZ + 0.05);
    this.steerPivot.position.copy(stemTop);
    // el pivote rota alrededor del eje de dirección
    this.steerAxis = axis.clone().negate(); // apunta arriba-atrás
    this.group.add(this.steerPivot);
    const P = (x, y, z) => new THREE.Vector3(x, y, z).sub(stemTop); // world-local → pivot-local

    // --- Manubrio (riser bar con sweep) ---
    const barPts = [
      [-W / 2, 0.022, 0.035], [-W * 0.34, 0.02, 0.022], [-0.12, 0.004, 0.004], [-0.04, 0, 0],
      [0.04, 0, 0], [0.12, 0.004, 0.004], [W * 0.34, 0.02, 0.022], [W / 2, 0.022, 0.035],
    ].map(([x, y, z]) => P(x, barY + y, barZ + z));
    const barCurve = new THREE.CatmullRomCurve3(barPts);
    const bar = new THREE.Mesh(new THREE.TubeGeometry(barCurve, 48, 0.0115, 10, false), mBlack);
    this.steerPivot.add(bar);

    // --- Potencia ---
    const stem = new THREE.Mesh(new THREE.BoxGeometry(0.048, 0.042, 0.075), mBlack);
    stem.position.copy(P(0, barY - 0.012, barZ + 0.035));
    this.steerPivot.add(stem);
    const cap = new THREE.Mesh(new THREE.CylinderGeometry(0.019, 0.019, 0.01, 16), mAccent);
    cap.position.copy(P(0, barY + 0.012, barZ + 0.065));
    this.steerPivot.add(cap);

    // --- Puños, manetas, guantes ---
    for (const side of [-1, 1]) {
      const gx = side * (W / 2 - 0.065);
      const grip = new THREE.Mesh(new THREE.CylinderGeometry(0.0165, 0.0165, 0.13, 12), mRubber);
      grip.rotation.z = Math.PI / 2;
      grip.position.copy(P(gx, barY + 0.021, barZ + 0.032));
      this.steerPivot.add(grip);
      const clamp = new THREE.Mesh(new THREE.CylinderGeometry(0.019, 0.019, 0.012, 12), mAccent);
      clamp.rotation.z = Math.PI / 2;
      clamp.position.copy(P(side * (W / 2 - 0.137), barY + 0.02, barZ + 0.03));
      this.steerPivot.add(clamp);

      // maneta de freno
      const lever = new THREE.Mesh(new THREE.BoxGeometry(0.1, 0.008, 0.016), mBlack);
      lever.position.copy(P(side * (W / 2 - 0.17), barY + 0.012, barZ - 0.03));
      lever.rotation.y = side * 0.35;
      this.steerPivot.add(lever);
      const master = new THREE.Mesh(new THREE.BoxGeometry(0.045, 0.028, 0.03), mBlack);
      master.position.copy(P(side * (W / 2 - 0.2), barY + 0.028, barZ + 0.015));
      this.steerPivot.add(master);

      // manguera de freno curvándose hacia la potencia/horquilla
      const hose = new THREE.CatmullRomCurve3([
        P(side * (W / 2 - 0.205), barY + 0.04, barZ + 0.005),
        P(side * 0.2, barY + 0.1, barZ - 0.08),
        P(side * 0.06, barY + 0.03, barZ - 0.12),
        P(side * 0.04, barY - 0.15, barZ - 0.12),
      ]);
      this.steerPivot.add(new THREE.Mesh(new THREE.TubeGeometry(hose, 24, 0.0028, 5), mBlack));

      // guante: palma envolviendo el puño + panel claro en el dorso
      const glove = new THREE.Mesh(new THREE.CapsuleGeometry(0.036, 0.075, 6, 12), mGlove);
      glove.rotation.z = Math.PI / 2;
      glove.scale.set(1, 1, 1.15);
      glove.position.copy(P(gx + side * 0.005, barY + 0.035, barZ + 0.038));
      this.steerPivot.add(glove);
      const panel = new THREE.Mesh(new THREE.CapsuleGeometry(0.02, 0.055, 4, 10), mGlovePanel);
      panel.rotation.z = Math.PI / 2;
      panel.scale.set(1, 0.6, 1);
      panel.position.copy(P(gx + side * 0.005, barY + 0.066, barZ + 0.045));
      this.steerPivot.add(panel);
      // dedos sobre la maneta (índice)
      const finger = new THREE.Mesh(new THREE.CapsuleGeometry(0.011, 0.07, 4, 8), mGlove);
      finger.rotation.z = Math.PI / 2;
      finger.rotation.y = side * 0.35;
      finger.position.copy(P(side * (W / 2 - 0.165), barY + 0.022, barZ - 0.028));
      this.steerPivot.add(finger);

      // antebrazo (muñeca → codo abierto hacia afuera y atrás)
      if (c.showArms) {
        const wrist = P(gx + side * 0.012, barY + 0.045, barZ + 0.07);
        const elbow = P(side * (W / 2 + 0.07), barY - 0.02, barZ + 0.46);
        const dir = elbow.clone().sub(wrist);
        const len = dir.length();
        const arm = new THREE.Mesh(new THREE.CylinderGeometry(0.046, 0.036, len, 12, 1, false), mSleeve);
        arm.position.copy(wrist).addScaledVector(dir, 0.5);
        arm.quaternion.setFromUnitVectors(new THREE.Vector3(0, 1, 0), dir.normalize());
        this.steerPivot.add(arm);
        const cuff = new THREE.Mesh(new THREE.CylinderGeometry(0.041, 0.041, 0.04, 12), mGlove);
        cuff.position.copy(wrist).addScaledVector(dir, 0.02);
        cuff.quaternion.copy(arm.quaternion);
        this.steerPivot.add(cuff);
      }
    }

    // --- Horquilla y rueda (rotan con la dirección) ---
    const crownPos = stemTop.clone().addScaledVector(axis, 0.2);
    const crown = new THREE.Mesh(new THREE.BoxGeometry(0.2, 0.035, 0.07), mLowers);
    crown.position.copy(crownPos.clone().sub(stemTop));
    crown.quaternion.setFromUnitVectors(new THREE.Vector3(0, 1, 0), axis.clone().negate());
    this.steerPivot.add(crown);
    const axleY = 0.37;
    const tAxle = (axleY - stemTop.y) / axis.y; // distancia a lo largo del eje hasta la altura del eje
    const offset = new THREE.Vector3(0, 0, -0.044);
    const axle = stemTop.clone().addScaledVector(axis, tAxle).add(offset);
    const q = new THREE.Quaternion().setFromUnitVectors(new THREE.Vector3(0, 1, 0), axis.clone().negate());
    for (const side of [-1, 1]) {
      const top = crownPos.clone().add(new THREE.Vector3(side * 0.07, 0, 0));
      const bottom = axle.clone().add(new THREE.Vector3(side * 0.07, 0, 0));
      const mid = top.clone().lerp(bottom, 0.42);
      const stL = top.distanceTo(mid);
      const st = new THREE.Mesh(new THREE.CylinderGeometry(0.0175, 0.0175, stL, 14), mStanchion);
      st.position.copy(top.clone().lerp(mid, 0.5).sub(stemTop));
      st.quaternion.copy(q);
      this.steerPivot.add(st);
      const lwL = mid.distanceTo(bottom);
      const lw = new THREE.Mesh(new THREE.CylinderGeometry(0.024, 0.021, lwL, 14), mLowers);
      lw.position.copy(mid.clone().lerp(bottom, 0.5).sub(stemTop));
      lw.quaternion.copy(q);
      this.steerPivot.add(lw);
    }
    // arco de la horquilla
    const arch = new THREE.Mesh(new THREE.TorusGeometry(0.07, 0.012, 8, 16, Math.PI), mLowers);
    const archPos = crownPos.clone().lerp(axle, 0.5);
    arch.position.copy(archPos.sub(stemTop));
    arch.quaternion.copy(q);
    this.steerPivot.add(arch);

    // Rueda 29"
    this.wheelSpin.position.copy(axle.clone().sub(stemTop));
    const wheel = new THREE.Group();
    const tire = new THREE.Mesh(new THREE.TorusGeometry(0.34, 0.032, 10, 48), mTire);
    tire.rotation.y = Math.PI / 2;
    wheel.add(tire);
    // tacos del neumático (instanciados)
    const knobGeo = new THREE.BoxGeometry(0.05, 0.014, 0.024);
    const knobs = new THREE.InstancedMesh(knobGeo, mTire, 64);
    const d = new THREE.Object3D();
    for (let i = 0; i < 64; i++) {
      const a = (i / 64) * Math.PI * 2;
      const r = 0.368;
      d.position.set((i % 2 ? 0.012 : -0.012), Math.cos(a) * r, Math.sin(a) * r);
      d.rotation.set(a, 0, 0);
      d.updateMatrix();
      knobs.setMatrixAt(i, d.matrix);
    }
    wheel.add(knobs);
    const rim = new THREE.Mesh(new THREE.TorusGeometry(0.305, 0.012, 6, 40), mRim);
    rim.rotation.y = Math.PI / 2;
    wheel.add(rim);
    const hub = new THREE.Mesh(new THREE.CylinderGeometry(0.025, 0.025, 0.11, 10), mRim);
    hub.rotation.z = Math.PI / 2;
    wheel.add(hub);
    const spokeGeo = new THREE.CylinderGeometry(0.0012, 0.0012, 0.29, 3);
    for (let i = 0; i < 16; i++) {
      const a = (i / 16) * Math.PI * 2;
      const sp = new THREE.Mesh(spokeGeo, mRim);
      sp.position.set(i % 2 ? 0.02 : -0.02, Math.cos(a) * 0.16, Math.sin(a) * 0.16);
      sp.rotation.x = a;
      wheel.add(sp);
    }
    this.wheelSpin.add(wheel);
    this.wheel = wheel;
    this.steerPivot.add(this.wheelSpin);

    // --- Cuadro (fijo, no gira): tubo de dirección, tubo superior y diagonal ---
    const headTop = stemTop.clone().addScaledVector(axis, 0.035);
    const headBot = stemTop.clone().addScaledVector(axis, 0.185);
    const addTube = (a, b, r, mat) => {
      const dir = b.clone().sub(a);
      const m = new THREE.Mesh(new THREE.CylinderGeometry(r, r, dir.length(), 14), mat);
      m.position.copy(a).addScaledVector(dir, 0.5);
      m.quaternion.setFromUnitVectors(new THREE.Vector3(0, 1, 0), dir.normalize());
      this.group.add(m);
      return m;
    };
    addTube(headTop, headBot, 0.029, mFrame);
    addTube(headTop.clone().add(new THREE.Vector3(0, -0.035, 0)), new THREE.Vector3(0, 0.78, 0.22), 0.024, mFrame);
    addTube(headBot.clone().add(new THREE.Vector3(0, 0.02, 0)), new THREE.Vector3(0, 0.3, -0.02), 0.03, mFrame);
    const cup = new THREE.Mesh(new THREE.CylinderGeometry(0.034, 0.034, 0.012, 16), mAccent);
    cup.position.copy(headTop);
    cup.quaternion.setFromUnitVectors(new THREE.Vector3(0, 1, 0), axis.clone().negate());
    this.group.add(cup);

    this.group.traverse((o) => {
      if (o.isMesh) { o.castShadow = true; o.receiveShadow = false; }
    });
    this.wheelRadius = 0.37;
    this._q = new THREE.Quaternion();
  }

  /** steerAngle en radianes (+ = derecha), speed m/s. */
  update(dt, steerAngle, speed) {
    // rotación alrededor del eje de dirección (−: la mano derecha va hacia atrás al girar a la derecha)
    this.steerPivot.quaternion.setFromAxisAngle(this.steerAxis, -steerAngle);
    this.wheel.rotation.x -= (speed / this.wheelRadius) * dt;
  }
}
