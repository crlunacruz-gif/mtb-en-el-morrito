import * as THREE from 'three';
import { mulberry32 } from '../utils/noise.js';

/**
 * Efectos de Milestone 1: partículas de polvo suspendidas en el aire
 * (quietas en el mundo → al pasar a su lado dan parallax y sensación de velocidad).
 * El roost, polvo de curvas y aterrizajes llegan en próximos milestones.
 */
export class FXSystem {
  constructor(scene, config) {
    this.count = config.fx.speedParticles;
    this.rng = mulberry32(99);
    const pos = new Float32Array(this.count * 3);
    const geo = new THREE.BufferGeometry();
    geo.setAttribute('position', new THREE.BufferAttribute(pos, 3));
    const sprite = makeDotTexture();
    this.material = new THREE.PointsMaterial({
      size: 0.05,
      map: sprite,
      color: new THREE.Color('#efe3cf'),
      transparent: true,
      opacity: 0.55,
      depthWrite: false,
      sizeAttenuation: true,
    });
    this.points = new THREE.Points(geo, this.material);
    this.points.frustumCulled = false;
    scene.add(this.points);
    this.initialized = false;
    this.box = { side: 7, up: 3.5, ahead: 26, behind: 3 };
    this._fwd = new THREE.Vector3();
    this._right = new THREE.Vector3();
    this.wind = new THREE.Vector3(0.6, 0.05, 0.25);
  }

  spawn(i, cam, anywhere) {
    const p = this.points.geometry.attributes.position.array;
    const r = this.rng;
    const b = this.box;
    const f = this._fwd, rt = this._right;
    const along = anywhere ? -b.behind + r() * (b.ahead + b.behind) : b.ahead * (0.7 + r() * 0.3);
    const side = (r() * 2 - 1) * b.side;
    const up = (r() * 2 - 1.1) * b.up;
    p[i * 3] = cam.position.x + f.x * along + rt.x * side;
    p[i * 3 + 1] = cam.position.y + f.y * along + up;
    p[i * 3 + 2] = cam.position.z + f.z * along + rt.z * side;
  }

  update(dt, camera, speed) {
    camera.getWorldDirection(this._fwd);
    this._right.set(-this._fwd.z, 0, this._fwd.x).normalize();
    const p = this.points.geometry.attributes.position.array;
    if (!this.initialized) {
      for (let i = 0; i < this.count; i++) this.spawn(i, camera, true);
      this.initialized = true;
    }
    const cx = camera.position.x, cy = camera.position.y, cz = camera.position.z;
    const f = this._fwd;
    for (let i = 0; i < this.count; i++) {
      p[i * 3] += this.wind.x * dt;
      p[i * 3 + 1] += this.wind.y * dt * Math.sin(i + p[i * 3] * 0.3);
      p[i * 3 + 2] += this.wind.z * dt;
      const dx = p[i * 3] - cx, dy = p[i * 3 + 1] - cy, dz = p[i * 3 + 2] - cz;
      const along = dx * f.x + dy * f.y + dz * f.z;
      const d2 = dx * dx + dy * dy + dz * dz;
      if (along < -this.box.behind || d2 > (this.box.ahead + 6) ** 2) this.spawn(i, camera, false);
    }
    this.points.geometry.attributes.position.needsUpdate = true;
    this.material.opacity = 0.25 + Math.min(0.45, speed / 25);
  }
}

function makeDotTexture() {
  const c = document.createElement('canvas');
  c.width = c.height = 32;
  const g = c.getContext('2d');
  const grd = g.createRadialGradient(16, 16, 0, 16, 16, 16);
  grd.addColorStop(0, 'rgba(255,255,255,1)');
  grd.addColorStop(0.4, 'rgba(255,255,255,0.5)');
  grd.addColorStop(1, 'rgba(255,255,255,0)');
  g.fillStyle = grd;
  g.fillRect(0, 0, 32, 32);
  const t = new THREE.CanvasTexture(c);
  t.colorSpace = THREE.SRGBColorSpace;
  return t;
}
