import { clamp, damp, createNoise2D } from '../utils/noise.js';

const G = 9.81;

/**
 * Física "arcade creíble" de la bici sobre el trail.
 *
 * Estado en coordenadas del trail (Frenet):
 *   s    distancia a lo largo del eje
 *   o    desplazamiento lateral (+ derecha)
 *   psi  ángulo de la bici respecto a la tangente del trail
 *   v    velocidad
 *
 * No depende del teclado: recibe un objeto input { steer, brake, ... } por frame.
 */
export class BikeController {
  constructor(trail, terrain, config) {
    this.trail = trail;
    this.terrain = terrain;
    this.cfg = config;
    this.noise = createNoise2D(4242);
    this._smp = {};
    this._smpAhead = {};
    this._info = {};
    this.reset();
  }

  reset(s = 0.5) {
    this.s = s;
    this.o = 0;
    this.psi = 0;
    this.v = 0;
    this.yawRate = 0;         // rad/s (mundo)
    this.steer = 0;           // input suavizado
    this.lean = 0;
    this.pitch = 0;
    this.bodyY = null;
    this.bodyVY = 0;
    this.suspension = 0;      // compresión (m, + = comprimido)
    this.distance = 0;
    this.onTrail = true;
    this.roughness = 0.3;
    this.impact = 0;          // golpe vertical reciente (para la cámara)
    this.finished = false;
    this.running = false;
    this.brake = 0;
    this.pos = { x: 0, y: 0, z: 0 };
    this.yaw = 0;
    this.update(0, { steer: 0, brake: 0 });
  }

  start() {
    this.running = true;
    this.v = this.cfg.startSpeed;
  }

  /** Curvatura máxima en los próximos metros (para anticipar curvas). */
  lookAheadKappa(dist) {
    let k = 0;
    for (let d = 0; d <= dist; d += 1) {
      k = Math.max(k, Math.abs(this.trail.sampleAt(this.s + d, this._smpAhead).kappa));
    }
    return k;
  }

  update(dt, input) {
    const c = this.cfg;
    const tr = this.trail;
    // sub-pasos fijos para estabilidad
    const steps = Math.max(1, Math.ceil(dt / (1 / 120)));
    const h = dt / steps;
    for (let i = 0; i < steps; i++) this.step(h, input, c, tr);
    this.updatePose(dt, c, tr);
  }

  step(dt, input, c, tr) {
    if (dt <= 0) return;
    const smp = tr.sampleAt(this.s, this._smp);
    const v = this.v;

    // ---------- STEERING ----------
    // input progresivo (no instantáneo)
    this.steer = damp(this.steer, input.steer, c.steerResponse, dt);
    // a mayor velocidad, menos capacidad de giro
    const maxYaw = c.maxYawRate / (1 + v / c.yawSpeedRef);
    // la bici sigue parte de la curva por sí sola (trailAssist)
    const pathYaw = smp.kappa * v * c.trailAssist;
    // ayuda en el borde: te devuelve suavemente hacia el sendero
    const edgeStart = smp.halfW * 0.75;
    let edgeYaw = 0;
    if (Math.abs(this.o) > edgeStart) {
      edgeYaw = -Math.sign(this.o) * (Math.abs(this.o) - edgeStart) * c.edgeAssist * 0.25 * Math.min(1, v / 4);
    }
    const alignYaw = -this.psi * c.alignAssist;
    const target = pathYaw + this.steer * maxYaw + edgeYaw + alignYaw;
    this.yawRate = damp(this.yawRate, target, c.yawInertia, dt);

    // ---------- CINEMÁTICA EN EL TRAIL ----------
    const denom = Math.max(0.3, 1 - smp.kappa * this.o);
    const sDot = (v * Math.cos(this.psi)) / denom;
    this.psi += (this.yawRate - smp.kappa * sDot) * dt;
    this.psi = clamp(this.psi, -1.1, 1.1);
    this.o += v * Math.sin(this.psi) * dt;
    this.s += sDot * dt;
    this.distance += v * dt;

    // muro suave fuera del sendero
    const wall = smp.halfW + c.maxOffset;
    if (Math.abs(this.o) > wall) {
      this.o = Math.sign(this.o) * wall;
      this.psi *= 0.5;
      this.v *= 1 - 1.5 * dt;
    }

    // ---------- VELOCIDAD ----------
    if (!this.running) { this.v = 0; return; }
    const off = Math.max(0, Math.abs(this.o) - smp.halfW);
    this.onTrail = off <= 0.05;
    const slope = smp.grade / Math.sqrt(1 + smp.grade * smp.grade); // sin(ángulo)
    let a = G * slope * c.gravityScale;
    a -= c.dragCoef * v * v;
    a -= c.rollResistance;
    a -= Math.min(1, off / 0.8) * c.offTrailDrag;
    this.brake = input.brake;
    a -= c.brakeDecel * input.brake;
    // anticipación de curvas cerradas (el rider "scrubea" velocidad)
    if (c.cornerAssist > 0) {
      const k = this.lookAheadKappa(Math.max(5, v * 1.1));
      if (k > 0.02) {
        const vCorner = Math.sqrt((c.cornerGrip * G) / k);
        if (v > vCorner) a -= (v - vCorner) * 3.0 * c.cornerAssist;
      }
    }
    if (this.finished) a = Math.min(a, -3.5);
    this.v = clamp(v + a * dt, this.finished ? 0 : c.minSpeed, c.maxSpeed);
    if (!this.finished && this.s >= tr.finishS) this.finished = true;
    if (this.s > tr.length - 2) { this.s = tr.length - 2; this.v = 0; }
  }

  updatePose(dt, c, tr) {
    const smp = tr.sampleAt(this.s, this._smp);
    const x = smp.x + smp.rightX * this.o;
    const z = smp.z + smp.rightZ * this.o;
    this.yaw = smp.theta + this.psi;
    const fx = Math.sin(this.yaw), fz = -Math.cos(this.yaw);
    const wb = 0.6; // medio wheelbase
    const info = this._info;
    const hFront = this.terrain.heightAt(x + fx * wb, z + fz * wb);
    const hRear = this.terrain.heightAt(x - fx * wb, z - fz * wb, info);
    const ground = (hFront + hRear) / 2;
    this.roughness = info.onTrail ? info.rough * 0.6 : 1.3;

    // suspensión: resorte-amortiguador entre suelo y cuerpo
    if (this.bodyY === null || dt === 0) { this.bodyY = ground; this.bodyVY = 0; }
    else {
      const k = 260, damping = 2 * Math.sqrt(k) * 0.55;
      const acc = k * (ground - this.bodyY) - damping * this.bodyVY;
      this.bodyVY += acc * dt;
      this.bodyY += this.bodyVY * dt;
      // la rueda nunca atraviesa el suelo
      if (this.bodyY < ground - 0.12) { this.bodyY = ground - 0.12; this.bodyVY = Math.max(0, this.bodyVY); }
      this.impact = damp(this.impact, Math.abs(acc) / 60, 10, dt);
    }
    this.suspension = ground - this.bodyY;
    this.pos.x = x; this.pos.y = this.bodyY; this.pos.z = z;

    this.pitch = damp(this.pitch, Math.atan2(hRear - hFront, wb * 2), 14, dt || 1);
    const leanTarget = clamp(Math.atan((this.v * this.yawRate) / G), -0.7, 0.7);
    this.lean = damp(this.lean, leanTarget, 6, dt || 1);
    this.section = smp.section;
    this.halfW = smp.halfW;
    this.elevation = this.bodyY;
  }

  /** Pendiente promedio que viene (para que la cámara mire hacia abajo antes). */
  slopeAhead(dist) {
    const a = this.trail.sampleAt(this.s, this._smpAhead).y;
    const b = this.trail.sampleAt(this.s + dist, this._smpAhead).y;
    return Math.atan2(a - b, dist);
  }

  get speedKmh() {
    return this.v * 3.6;
  }
}
