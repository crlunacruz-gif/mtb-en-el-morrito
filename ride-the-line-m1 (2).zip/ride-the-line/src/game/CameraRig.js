import * as THREE from 'three';
import { clamp, damp, createNoise2D } from '../utils/noise.js';

/**
 * Cámara POV tipo GoPro en casco.
 *  - La bici (cockpit) sigue al suelo con su suspensión y vibra más.
 *  - La cabeza filtra: las piernas absorben parte del terreno.
 *  - Mira hacia la curva que viene y hacia abajo de la pendiente.
 *  - FOV dinámico leve con la velocidad.
 */
export class CameraRig {
  constructor(camera, bikeModel, bike, trail, config) {
    this.camera = camera;
    this.camera.rotation.order = 'YXZ';
    this.model = bikeModel;
    this.bike = bike;
    this.trail = trail;
    this.cfg = config;
    this.noise = createNoise2D(777);
    this._smp = {};
    this.headBase = null;
    this.trendV = 0;
    this.prevBodyY = null;
    this.yawLook = 0;
    this.fov = config.camera.fov;
    this.shakeT = 0;
    this.idleT = 0;
  }

  reset() {
    this.headBase = null;
    this.prevBodyY = null;
    this.trendV = 0;
    this.yawLook = 0;
  }

  update(dt) {
    const cc = this.cfg.camera;
    const b = this.bike;
    const m = this.model.group;
    const v = b.v;
    this.idleT += dt;

    // ---------------- Vibración (depende de la distancia recorrida → frecuencia ∝ velocidad)
    const rough = b.roughness;
    const speedF = clamp(v / 9, 0, 1.4);
    const dist = b.distance;
    const n = this.noise;
    const amp = cc.shake * (0.0025 + 0.011 * rough) * speedF;
    const vibY = amp * (n(dist * 2.1, 0.3) * 0.7 + n(dist * 5.3, 4.1) * 0.3);
    const vibRoll = amp * 1.6 * n(dist * 1.7, 8.8);
    const vibPitch = amp * 1.8 * n(dist * 2.6, 12.4);

    // ---------------- Bici / cockpit
    m.position.set(b.pos.x, b.pos.y + vibY * 1.4, b.pos.z);
    m.rotation.set(-b.pitch + vibPitch * 1.4, -b.yaw, -b.lean * 0.75 + vibRoll * 1.2);
    const steerVis = clamp(b.steer * 0.1 + (b.yawRate - this.pathYawRate()) * 0.05, -0.25, 0.25) + b.psi * 0.15;
    this.model.update(dt, steerVis, v);

    // ---------------- Cabeza
    const bodyY = b.pos.y;
    if (this.headBase === null) { this.headBase = bodyY; this.prevBodyY = bodyY; }
    if (dt > 0) {
      const inst = (bodyY - this.prevBodyY) / dt;
      this.trendV = damp(this.trendV, inst, 3.5, dt);
      this.prevBodyY = bodyY;
      const lam = cc.headDamping;
      // seguidor de 2º orden: sin retraso en pendientes constantes, filtra baches
      this.headBase = damp(this.headBase, bodyY + this.trendV / lam, lam, dt);
    }
    // respiración/balanceo leve cuando está quieto
    const idle = b.running ? 0 : Math.sin(this.idleT * 1.3) * 0.006;

    const yaw = b.yaw;
    const fx = Math.sin(yaw), fz = -Math.cos(yaw);
    const rx = Math.cos(yaw), rz = Math.sin(yaw);
    // el cuerpo se inclina con la bici: la cabeza se desplaza lateralmente
    const leanShift = Math.sin(b.lean * 0.75) * cc.height * 0.5;
    const hx = b.pos.x + fx * cc.forwardOffset + rx * leanShift;
    const hz = b.pos.z + fz * cc.forwardOffset + rz * leanShift;
    const cam = this.camera;
    cam.position.set(hx, this.headBase + cc.height + vibY * 0.6 + idle - b.suspension * 0.25, hz);

    // ---------------- Orientación
    // mirar hacia donde va el trail (los riders miran la salida de la curva)
    const look = this.lookIntoTurn(cc.lookAhead + v * 0.35);
    this.yawLook = damp(this.yawLook, look, 4, dt || 1);
    const slopeAhead = b.slopeAhead(cc.lookAhead);
    const pitchBase = b.pitch * (1 - cc.lookAheadWeight) + slopeAhead * cc.lookAheadWeight;
    const tilt = THREE.MathUtils.degToRad(cc.tiltDeg);
    cam.rotation.set(
      tilt - pitchBase + vibPitch + b.impact * 0.004,
      -(yaw + this.yawLook * 0.4),
      clamp(-b.lean * cc.leanFactor, -0.3, 0.3) + vibRoll,
    );

    // ---------------- FOV dinámico
    const tFov = cc.fov + (cc.fovHighSpeed - cc.fov) * Math.pow(clamp(v / cc.fovSpeedRef, 0, 1), 1.6);
    this.fov = damp(this.fov, tFov, 2.5, dt || 1);
    if (Math.abs(cam.fov - this.fov) > 0.01) {
      cam.fov = this.fov;
      cam.updateProjectionMatrix();
    }
  }

  pathYawRate() {
    const s = this.trail.sampleAt(this.bike.s, this._smp);
    return s.kappa * this.bike.v;
  }

  /** Ángulo (rad) entre el rumbo de la bici y un punto del trail más adelante. */
  lookIntoTurn(dist) {
    const b = this.bike;
    const p = this.trail.sampleAt(b.s + dist, this._smp);
    const o = b.o * 0.5;
    const tx = p.x + p.rightX * o - b.pos.x;
    const tz = p.z + p.rightZ * o - b.pos.z;
    const target = Math.atan2(tx, -tz); // mismo convenio que theta
    let d = target - b.yaw;
    while (d > Math.PI) d -= Math.PI * 2;
    while (d < -Math.PI) d += Math.PI * 2;
    return clamp(d, -0.9, 0.9);
  }
}
