import * as THREE from 'three';
import GUI from 'lil-gui';
import { TrailGenerator } from './TrailGenerator.js';
import { Terrain } from './Terrain.js';
import { Environment } from './Environment.js';
import { BikeController } from './BikeController.js';
import { BikeModel } from './BikeModel.js';
import { CameraRig } from './CameraRig.js';
import { FXSystem } from './FXSystem.js';
import { AudioSystem } from './AudioSystem.js';
import { GameState } from './GameState.js';
import { KeyboardInput } from './input/KeyboardInput.js';
import { HUD } from '../ui/HUD.js';
import { clamp } from '../utils/noise.js';

export class Game {
  constructor(container, hudRoot, config) {
    this.cfg = config;
    this.container = container;
    this.params = new URLSearchParams(location.search);

    // ?q=low → sin sombras ni antialias (para equipos modestos)
    this.lowQuality = this.params.get('q') === 'low';
    const renderer = new THREE.WebGLRenderer({ antialias: !this.lowQuality, powerPreference: 'high-performance' });
    renderer.setPixelRatio(Math.min(window.devicePixelRatio, this.lowQuality ? 1 : 1.75));
    renderer.setSize(window.innerWidth, window.innerHeight);
    renderer.outputColorSpace = THREE.SRGBColorSpace;
    renderer.toneMapping = THREE.ACESFilmicToneMapping;
    renderer.toneMappingExposure = 1.05;
    renderer.shadowMap.enabled = !this.lowQuality;
    renderer.shadowMap.type = THREE.PCFShadowMap;
    container.appendChild(renderer.domElement);
    this.renderer = renderer;

    this.camera = new THREE.PerspectiveCamera(config.camera.fov, window.innerWidth / window.innerHeight, 0.03, 12000);

    this.hud = new HUD(hudRoot);
    this.state = new GameState();
    this.input = new KeyboardInput();
    this.audio = new AudioSystem(config.fx.audio);
    this.timer = new THREE.Timer();
    this.timer.connect(document);
    this.fps = 60;

    window.addEventListener('resize', () => this.onResize());
    window.addEventListener('keydown', (e) => this.onKey(e));
    this.hud.startBtn.addEventListener('click', () => this.startRide());
    this.hud.againBtn.addEventListener('click', () => this.restart());
  }

  /** Construye (o reconstruye) el mundo a partir de la configuración. */
  buildWorld() {
    const t0 = performance.now();
    const cfg = this.cfg;
    if (this.scene) this.disposeScene(this.scene);
    const scene = new THREE.Scene();
    this.scene = scene;

    this.trail = new TrailGenerator(cfg.trail, cfg.seed);
    this.terrain = new Terrain(this.trail, cfg.terrain, cfg.seed);
    this.terrain.build(scene);
    this.env = new Environment(scene, this.renderer, this.terrain, this.trail, cfg.seed);
    this.bike = new BikeController(this.trail, this.terrain, cfg.bike);
    this.model = new BikeModel(cfg);
    scene.add(this.model.group);
    this.rig = new CameraRig(this.camera, this.model, this.bike, this.trail, cfg);
    this.fx = new FXSystem(scene, cfg);
    scene.add(this.camera);

    this.rig.update(0);
    this.buildTime = performance.now() - t0;
    console.info(
      `[RideTheLine] mundo generado en ${this.buildTime.toFixed(0)} ms · trail ${this.trail.finishS.toFixed(0)} m · ` +
      `terreno ${this.terrain.gridInfo.vertices} vértices · rocas ${this.terrain.rockCounts.near + this.terrain.rockCounts.far}`,
    );
    console.table(this.trail.sectionStats.map((s) => ({
      sección: s.name, largo_m: s.length.toFixed(0), pendiente: `${(s.grade * 100).toFixed(0)} %`, desnivel_m: s.dropM.toFixed(1),
    })));
  }

  disposeScene(scene) {
    scene.traverse((o) => {
      if (o.geometry) o.geometry.dispose();
      if (o.material) {
        const mats = Array.isArray(o.material) ? o.material : [o.material];
        mats.forEach((m) => { for (const k in m) if (m[k] && m[k].isTexture) m[k].dispose(); m.dispose(); });
      }
    });
    if (scene.environment) scene.environment.dispose();
  }

  init() {
    this.buildWorld();
    this.hud.setReady();
    if (this.params.has('gui')) this.toggleGui();
    if (this.params.has('s')) {
      // atajo de testeo: ?s=200 arranca en ese punto del trail
      this.bike.reset(parseFloat(this.params.get('s')));
      this.rig.reset();
    }
    if (this.params.has('autostart')) this.startRide();
    this.renderer.setAnimationLoop(() => this.frame());
  }

  startRide() {
    if (this.state.phase === 'riding') return;
    this.audio.start();
    this.hud.showIntro(false);
    this.hud.hideFinish();
    this.state.startRide();
    this.startElevation = this.bike.elevation;
    this.bike.start();
  }

  restart() {
    this.bike.reset();
    this.rig.reset();
    this.state.reset();
    this.hud.hideFinish();
    this.hud.lastSection = -1;
    this.startRide();
  }

  onKey(e) {
    if (e.code === 'Enter' && this.state.phase === 'intro') this.startRide();
    if (e.code === 'KeyR') this.restart();
    if (e.code === 'KeyM') this.audio.toggleMute();
    if (e.code === 'KeyG') this.toggleGui();
  }

  onResize() {
    this.camera.aspect = window.innerWidth / window.innerHeight;
    this.camera.updateProjectionMatrix();
    this.renderer.setSize(window.innerWidth, window.innerHeight);
  }

  /** Piloto automático simple (sólo para testeo: ?bot=1). */
  botInput() {
    const b = this.bike;
    const steer = clamp(-(b.o * 1.4 + b.psi * 2.5), -1, 1);
    return { steer, brake: 0, drift: false, pop: false };
  }

  frame() {
    this.timer.update();
    const rawDt = this.timer.getDelta();
    const dt = Math.min(rawDt, 1 / 20);
    this.fps = this.fps * 0.95 + (1 / Math.max(rawDt, 1e-4)) * 0.05;
    const input = this.params.has('bot') ? this.botInput() : this.input.read();

    if (this.state.phase === 'riding' || this.state.phase === 'finished') {
      this.bike.update(dt, input);
      this.state.track(dt, this.bike.v);
      if (this.bike.finished && this.state.phase === 'riding') {
        this.state.finish();
        const drop = this.startElevation - this.bike.elevation;
        this.hud.showFinish(this.state.time, this.state.maxSpeed * 3.6, this.state.avgSpeed * 3.6, drop);
      }
    } else {
      this.bike.update(dt, { steer: 0, brake: 0 });
    }

    this.rig.update(dt);
    this.fx.update(dt, this.camera, this.bike.v);
    this.env.update(dt, this.bike.pos);
    this.audio.update(this.bike.v, this.bike.roughness, this.bike.onTrail);
    this.hud.update(dt, this.bike, this.trail);
    this.hud.updateDebug([
      `FPS ${this.fps.toFixed(0)}`,
      `sección ${this.trail.sections[this.bike.section].name}`,
      `s ${this.bike.s.toFixed(1)} / ${this.trail.finishS.toFixed(0)} m`,
      `elev ${this.bike.elevation.toFixed(1)} m`,
      `pendiente ${(this.trail.sampleAt(this.bike.s).grade * 100).toFixed(0)} %`,
      `offset ${this.bike.o.toFixed(2)} m  (½ancho ${this.bike.halfW.toFixed(2)})`,
      `${this.bike.onTrail ? 'en trail' : 'FUERA'}`,
      `t ${this.state.time.toFixed(1)} s`,
      `draw calls ${this.renderer.info.render.calls}`,
    ]);

    this.renderer.render(this.scene, this.camera);
  }

  // ---------------------------------------------------------------------------
  //  Panel de ajuste en vivo (tecla G)
  // ---------------------------------------------------------------------------
  toggleGui() {
    const on = this.hud.toggleDebug();
    document.body.classList.toggle('debug-on', on);
    if (!this.gui) this.buildGui();
    this.gui.show(on);
  }

  buildGui() {
    const c = this.cfg;
    const gui = new GUI({ title: 'Ride the Line · ajustes' });
    const fc = gui.addFolder('Cámara (en vivo)');
    fc.add(c.camera, 'height', 1.2, 2.0, 0.01).name('altura');
    fc.add(c.camera, 'fov', 50, 100, 1).name('FOV');
    fc.add(c.camera, 'fovHighSpeed', 50, 110, 1).name('FOV alta vel.');
    fc.add(c.camera, 'tiltDeg', -35, 5, 0.5).name('inclinación');
    fc.add(c.camera, 'leanFactor', 0, 1.2, 0.01).name('inclinación en curva');
    fc.add(c.camera, 'shake', 0, 3, 0.05).name('vibración');
    fc.add(c.camera, 'lookAheadWeight', 0, 1, 0.01).name('mirar pendiente');
    const fb = gui.addFolder('Bici (en vivo)');
    fb.add(c.bike, 'gravityScale', 0.3, 2.0, 0.01).name('gravedad (velocidad)');
    fb.add(c.bike, 'maxSpeed', 6, 25, 0.1).name('vel. máx (m/s)');
    fb.add(c.bike, 'dragCoef', 0.002, 0.03, 0.0005).name('resistencia aire');
    fb.add(c.bike, 'trailAssist', 0, 1, 0.01).name('asistencia curva');
    fb.add(c.bike, 'maxYawRate', 0.5, 4, 0.05).name('giro máx');
    fb.add(c.bike, 'steerResponse', 1, 15, 0.1).name('respuesta dirección');
    fb.add(c.bike, 'cornerAssist', 0, 1, 0.01).name('auto-freno curvas');
    const ft = gui.addFolder('Trail (requiere regenerar)');
    ft.add(c.trail, 'startElevation', 60, 250, 1).name('elevación inicio');
    ft.add(c.trail, 'endElevation', 5, 150, 1).name('elevación final');
    ft.add(c.trail, 'lengthScale', 0.5, 2, 0.05).name('longitud');
    ft.add(c.trail, 'curveIntensity', 0, 1.5, 0.05).name('intensidad curvas');
    ft.add(c.trail, 'widthScale', 0.5, 2.5, 0.05).name('ancho');
    ft.add(c, 'seed', 1, 999, 1).name('semilla');
    ft.add({ regen: () => { this.buildWorld(); this.state.reset(); this.hud.showIntro(true); this.hud.hideFinish(); } }, 'regen')
      .name('↻ Regenerar trail');
    gui.add({ copy: () => {
      const out = JSON.stringify({ trail: { ...c.trail, sections: undefined }, bike: c.bike, camera: c.camera }, null, 2);
      navigator.clipboard?.writeText(out);
      console.log(out);
    } }, 'copy').name('Copiar valores (consola)');
    this.gui = gui;
  }
}
