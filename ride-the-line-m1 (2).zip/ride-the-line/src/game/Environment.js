import * as THREE from 'three';
import { mulberry32, lerp } from '../utils/noise.js';
import { makeWaterNormalTexture } from '../utils/textures.js';

// Cielo costero de Lima: gris perla, brillante y difuso (panza de burro).
export const SKY = {
  horizon: new THREE.Color('#d9d8d2'),
  zenith: new THREE.Color('#a9b3b8'),
  fog: new THREE.Color('#d3d3cd'),
};

/**
 * Cielo, niebla, luces, océano Pacífico, Lima estilizada al fondo,
 * isla en el horizonte y la cruz/antena en la cumbre (hito del Morro).
 */
export class Environment {
  constructor(scene, renderer, terrain, trail, seed) {
    this.scene = scene;
    this.renderer = renderer;
    this.terrain = terrain;
    this.trail = trail;
    this.rng = mulberry32(seed * 5 + 2);

    scene.background = SKY.fog.clone();
    scene.fog = new THREE.Fog(SKY.fog, 60, 4300);

    this.buildSky();
    this.buildLights();
    this.buildOcean();
    this.buildLima();
    this.buildHorizon();
    this.buildLandmark();
  }

  buildSky() {
    const geo = new THREE.SphereGeometry(9500, 32, 16);
    const mat = new THREE.ShaderMaterial({
      side: THREE.BackSide,
      depthWrite: false,
      fog: false,
      uniforms: {
        uHorizon: { value: SKY.horizon },
        uZenith: { value: SKY.zenith },
        uSunDir: { value: new THREE.Vector3(-0.45, 0.55, -0.7).normalize() },
      },
      vertexShader: /* glsl */ `
        varying vec3 vDir;
        void main() {
          vDir = normalize(position);
          vec4 p = projectionMatrix * modelViewMatrix * vec4(position, 1.0);
          gl_Position = p.xyww;
        }`,
      fragmentShader: /* glsl */ `
        uniform vec3 uHorizon; uniform vec3 uZenith; uniform vec3 uSunDir;
        varying vec3 vDir;
        void main() {
          float h = clamp(vDir.y, 0.0, 1.0);
          vec3 col = mix(uHorizon, uZenith, pow(h, 0.55));
          float sun = pow(max(dot(normalize(vDir), uSunDir), 0.0), 6.0);
          col += vec3(0.10, 0.09, 0.07) * sun;
          gl_FragColor = vec4(col, 1.0);
          #include <colorspace_fragment>
        }`,
    });
    this.sky = new THREE.Mesh(geo, mat);
    this.sky.frustumCulled = false;
    this.sky.renderOrder = -1;
    this.scene.add(this.sky);

    // Entorno para reflejos (océano, materiales PBR)
    const pmrem = new THREE.PMREMGenerator(this.renderer);
    const envScene = new THREE.Scene();
    const envSky = new THREE.Mesh(new THREE.SphereGeometry(100, 32, 16), mat.clone());
    envScene.add(envSky);
    this.scene.environment = pmrem.fromScene(envScene, 0.02).texture;
    this.scene.environmentIntensity = 0.55;
    pmrem.dispose();
  }

  buildLights() {
    const hemi = new THREE.HemisphereLight(0xe4e8ea, 0x9a8466, 1.15);
    this.scene.add(hemi);

    const sun = new THREE.DirectionalLight(0xfff0da, 2.1);
    sun.castShadow = true;
    sun.shadow.mapSize.set(2048, 2048);
    const S = 32;
    Object.assign(sun.shadow.camera, { left: -S, right: S, top: S, bottom: -S, near: 1, far: 260 });
    sun.shadow.bias = -0.0004;
    sun.shadow.normalBias = 0.03;
    sun.shadow.radius = 3;
    this.sunOffset = new THREE.Vector3(-70, 110, -55);
    this.scene.add(sun);
    this.scene.add(sun.target);
    this.sun = sun;
  }

  buildOcean() {
    const normal = makeWaterNormalTexture(7);
    normal.repeat.set(900, 900);
    const mat = new THREE.MeshStandardMaterial({
      color: new THREE.Color('#566c76'),
      roughness: 0.32,
      metalness: 0.0,
      normalMap: normal,
      normalScale: new THREE.Vector2(0.28, 0.28),
      envMapIntensity: 1.1,
    });
    const geo = new THREE.PlaneGeometry(40000, 40000, 1, 1);
    geo.rotateX(-Math.PI / 2);
    const ocean = new THREE.Mesh(geo, mat);
    ocean.position.y = 0;
    ocean.receiveShadow = false;
    this.scene.add(ocean);
    this.ocean = ocean;
    this.waterNormal = normal;
  }

  // Lima: meseta con acantilados (Costa Verde) y ciudad de bloques, a la derecha-adelante.
  buildLima() {
    const rng = this.rng;
    const b = this.trail.bounds;
    const ox = b.maxX, oz = b.minZ; // referencia
    // borde costero (acantilado) de sur a norte
    const coast = [
      [ox + 900, oz + 320], [ox + 950, oz - 250], [ox + 1100, oz - 900],
      [ox + 1150, oz - 1600], [ox + 1700, oz - 2400], [ox + 2400, oz - 3200],
      [ox + 3300, oz - 3900], [ox + 4400, oz - 4500],
    ];
    const shape = new THREE.Shape();
    shape.moveTo(coast[0][0], -coast[0][1]);
    for (let i = 1; i < coast.length; i++) shape.lineTo(coast[i][0], -coast[i][1]);
    shape.lineTo(ox + 9000, -(oz - 4500));
    shape.lineTo(ox + 9000, -(oz + 320));
    shape.lineTo(coast[0][0], -coast[0][1]);
    const cliffH = 45;
    const geo = new THREE.ExtrudeGeometry(shape, { depth: cliffH, bevelEnabled: false, curveSegments: 1 });
    geo.rotateX(-Math.PI / 2); // shape XY → XZ (y del shape = −z)
    const mat = new THREE.MeshStandardMaterial({ color: '#94897a', roughness: 1, flatShading: true, side: THREE.DoubleSide });
    const plateau = new THREE.Mesh(geo, mat);
    plateau.position.y = -2;
    this.scene.add(plateau);

    // playa al pie del acantilado
    // Ciudad: bloques instanciados
    const box = new THREE.BoxGeometry(1, 1, 1);
    box.translate(0, 0.5, 0);
    const cityMat = new THREE.MeshStandardMaterial({ roughness: 0.85, metalness: 0 });
    const N = 2600;
    const city = new THREE.InstancedMesh(box, cityMat, N);
    const dummy = new THREE.Object3D();
    const col = new THREE.Color();
    const tones = ['#d6d2ca', '#c8c3b8', '#bab4a8', '#dcd6ca', '#aba7a0', '#c9bca7', '#b9bec2'];
    let k = 0;
    for (let i = 0; i < N; i++) {
      // punto a lo largo de la costa + distancia tierra adentro
      const t = rng() * (coast.length - 1.01);
      const ci = Math.floor(t), f = t - ci;
      const cx = lerp(coast[ci][0], coast[ci + 1][0], f);
      const cz = lerp(coast[ci][1], coast[ci + 1][1], f);
      const inland = 25 + Math.pow(rng(), 1.6) * 1400;
      const x = cx + inland * 0.93 + (rng() - 0.5) * 40;
      const z = cz + inland * 0.35 + (rng() - 0.5) * 40;
      const tower = inland < 160 && rng() < 0.16;
      const h = tower ? 28 + rng() * 45 : 4 + Math.pow(rng(), 2.5) * 16;
      const w = tower ? 14 + rng() * 14 : 12 + rng() * 26;
      dummy.position.set(x, cliffH - 2, z);
      dummy.scale.set(w, h, w * (0.7 + rng() * 0.6));
      dummy.rotation.y = 0.35 + (rng() - 0.5) * 0.2;
      dummy.updateMatrix();
      city.setMatrixAt(k, dummy.matrix);
      col.set(tones[Math.floor(rng() * tones.length)]);
      city.setColorAt(k, col);
      k++;
    }
    city.count = k;
    city.instanceMatrix.needsUpdate = true;
    city.computeBoundingSphere();
    this.scene.add(city);
  }

  // Cerros lejanos (estribaciones andinas) e isla en el horizonte.
  buildHorizon() {
    const rng = this.rng;
    const hazeMat = (c) => new THREE.MeshBasicMaterial({ color: c, fog: false });
    const b = this.trail.bounds;
    const group = new THREE.Group();
    // cordillera detrás de Lima
    for (let i = 0; i < 26; i++) {
      const ang = lerp(-0.15, 1.25, i / 25) + (rng() - 0.5) * 0.08; // abanico a la derecha-adelante
      const dist = 7800 + rng() * 1200;
      const x = b.maxX + Math.sin(ang) * dist;
      const z = b.minZ - Math.cos(ang) * dist;
      const r = 1100 + rng() * 1300;
      const h = 220 + rng() * 380;
      const g = new THREE.ConeGeometry(r, h, 5 + Math.floor(rng() * 3), 1);
      const far = i % 2;
      const m = new THREE.Mesh(g, hazeMat(far ? '#c6c8c5' : '#bfc1bd'));
      m.position.set(x, h / 2 - 20, z);
      m.rotation.y = rng() * Math.PI;
      group.add(m);
    }
    // isla (San Lorenzo) a la izquierda-adelante
    const isl = new THREE.SphereGeometry(1, 12, 6);
    const island = new THREE.Mesh(isl, hazeMat('#bfc2bf'));
    island.scale.set(2600, 260, 700);
    island.position.set(b.minX - 3200, -60, b.minZ - 5200);
    island.rotation.y = 0.6;
    group.add(island);
    this.scene.add(group);
  }

  // Cruz blanca y antena sobre la cumbre secundaria (hito inspirado en el Morro Solar)
  buildLandmark() {
    const peak = this.terrain.peaks.find((p) => p.landmark);
    if (!peak) return;
    let best = { h: -1e9, x: peak.x, z: peak.z };
    for (let i = -3; i <= 3; i++) {
      for (let j = -3; j <= 3; j++) {
        const x = peak.x + i * 12, z = peak.z + j * 12;
        const h = this.terrain.heightAt(x, z);
        if (h > best.h) best = { h, x, z };
      }
    }
    const white = new THREE.MeshStandardMaterial({ color: '#f1efe9', roughness: 0.7 });
    const cross = new THREE.Group();
    const post = new THREE.Mesh(new THREE.BoxGeometry(1.4, 22, 1.4), white);
    post.position.y = 11;
    const arm = new THREE.Mesh(new THREE.BoxGeometry(11, 1.4, 1.4), white);
    arm.position.y = 15.5;
    cross.add(post, arm);
    cross.position.set(best.x, best.h - 0.5, best.z);
    cross.rotation.y = 0.5;
    this.scene.add(cross);

    const mastMat = new THREE.MeshStandardMaterial({ color: '#8c8c8c', roughness: 0.6, metalness: 0.3 });
    const mast = new THREE.Mesh(new THREE.CylinderGeometry(0.25, 0.6, 38, 5), mastMat);
    mast.position.set(best.x + 26, this.terrain.heightAt(best.x + 26, best.z + 10) + 18, best.z + 10);
    this.scene.add(mast);
    this.landmark = best;
  }

  update(dt, focus) {
    // sombra que sigue al rider (con snapping para evitar parpadeo)
    const sun = this.sun;
    const snap = 0.5;
    const fx = Math.round(focus.x / snap) * snap;
    const fz = Math.round(focus.z / snap) * snap;
    sun.target.position.set(fx, focus.y, fz);
    sun.position.set(fx, focus.y, fz).add(this.sunOffset);
    sun.target.updateMatrixWorld();
    // olas
    this.waterNormal.offset.x += dt * 0.004;
    this.waterNormal.offset.y += dt * 0.0025;
  }
}
