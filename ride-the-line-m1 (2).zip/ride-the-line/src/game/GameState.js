/**
 * Estado de la partida. En Milestone 1: intro → riding → finished.
 * (crash, countdown y scoring se agregarán aquí en próximos milestones)
 */
export class GameState {
  constructor() {
    this.reset();
  }

  reset() {
    this.phase = 'intro';
    this.time = 0;
    this.maxSpeed = 0;
    this.speedSum = 0;
    this.samples = 0;
  }

  startRide() {
    this.phase = 'riding';
    this.time = 0;
  }

  finish() {
    this.phase = 'finished';
  }

  track(dt, speed) {
    if (this.phase !== 'riding') return;
    this.time += dt;
    this.maxSpeed = Math.max(this.maxSpeed, speed);
    this.speedSum += speed * dt;
  }

  get avgSpeed() {
    return this.time > 0 ? this.speedSum / this.time : 0;
  }
}
