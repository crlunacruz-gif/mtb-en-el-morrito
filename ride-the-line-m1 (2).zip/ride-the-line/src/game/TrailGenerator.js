import { createNoise2D, clamp, lerp } from '../utils/noise.js';

const DEG = Math.PI / 180;

/**
 * Genera la línea central del trail como una secuencia densa de muestras 3D.
 *
 * Convenciones:
 *  - heading θ = 0 mira hacia −Z. θ positivo gira a la derecha (+X).
 *  - dir   = ( sin θ, 0, −cos θ )
 *  - right = ( cos θ, 0,  sin θ )
 *  - offset lateral o > 0 = a la derecha del eje.
 */
export class TrailGenerator {
  constructor(config, seed = 1) {
    this.cfg = config;
    this.noise = createNoise2D(seed * 7 + 3);
    this.ds = 0.5;
    this.build();
  }

  build() {
    const cfg = this.cfg;
    const ds = this.ds;
    const L = cfg.lengthScale;
    const sections = cfg.sections;

    // 1) Curvatura y propiedades crudas por muestra
    const kRaw = [];
    const secIdx = [];
    const sectionStarts = [];
    for (let si = 0; si < sections.length; si++) {
      const sec = sections[si];
      sectionStarts.push(kRaw.length * ds);
      for (const cmd of sec.path) {
        if (cmd[0] === 'S') {
          const n = Math.max(1, Math.round((cmd[1] * L) / ds));
          for (let i = 0; i < n; i++) { kRaw.push(0); secIdx.push(si); }
        } else {
          const ang = cmd[1] * DEG * cfg.curveIntensity;
          const radius = Math.max(3, cmd[2] * L);
          const arc = Math.abs(ang) * radius;
          const n = Math.max(1, Math.round(arc / ds));
          const k = ang / (n * ds);
          for (let i = 0; i < n; i++) { kRaw.push(k); secIdx.push(si); }
        }
      }
    }
    const finishCount = kRaw.length;
    const runN = Math.round(cfg.runoutLength / ds);
    for (let i = 0; i < runN; i++) { kRaw.push(0); secIdx.push(sections.length - 1); }
    // pequeño margen previo (plataforma de salida) — se construye hacia atrás
    const N = kRaw.length + 1;

    this.count = N;
    this.length = (N - 1) * ds;
    this.finishS = finishCount * ds;
    this.sectionStarts = sectionStarts;
    this.sections = sections;

    const boxSmooth = (arr, windowM) => {
      const w = Math.max(1, Math.round(windowM / ds / 2));
      const out = new Float32Array(arr.length);
      // prefix sums
      const pre = new Float64Array(arr.length + 1);
      for (let i = 0; i < arr.length; i++) pre[i + 1] = pre[i] + arr[i];
      for (let i = 0; i < arr.length; i++) {
        const a = Math.max(0, i - w), b = Math.min(arr.length, i + w + 1);
        out[i] = (pre[b] - pre[a]) / (b - a);
      }
      return out;
    };

    // 2) Suavizado de curvatura (transiciones tipo clotoide) — dos pasadas
    let kappa = boxSmooth(kRaw, cfg.curvatureSmoothing);
    kappa = boxSmooth(Array.from(kappa), cfg.curvatureSmoothing * 0.5);

    // 3) Propiedades por sección, suavizadas
    const prop = (fn) => {
      const a = new Array(N - 1);
      for (let i = 0; i < N - 1; i++) a[i] = fn(sections[secIdx[i]], i);
      a.push(a[a.length - 1]);
      return a;
    };
    const halfW = boxSmooth(prop((s) => (s.width * cfg.widthScale) / 2), 10);
    const rough = boxSmooth(prop((s) => s.roughness), 12);
    const expL = boxSmooth(prop((s) => s.exposure[0]), 20);
    const expR = boxSmooth(prop((s) => s.exposure[1]), 20);
    const rockD = boxSmooth(prop((s) => s.rockDensity), 10);
    const gradeRel = boxSmooth(prop((s, i) => (i >= finishCount ? 0 : s.grade)), 14);

    // 4) Integración de posición en planta
    const x = new Float32Array(N), z = new Float32Array(N), y = new Float32Array(N);
    const theta = new Float32Array(N);
    let th = 0, px = 0, pz = 0;
    for (let i = 0; i < N; i++) {
      x[i] = px; z[i] = pz; theta[i] = th;
      const k = kappa[Math.min(i, N - 2)];
      // integración de punto medio
      const thMid = th + k * ds * 0.5;
      px += Math.sin(thMid) * ds;
      pz -= Math.cos(thMid) * ds;
      th += k * ds;
    }

    // 5) Elevación: pendiente relativa reescalada para cumplir start/end
    let sumG = 0;
    for (let i = 0; i < finishCount; i++) sumG += gradeRel[i] * ds;
    const drop = cfg.startElevation - cfg.endElevation;
    const gScale = sumG > 0 ? drop / sumG : 0;
    const grade = new Float32Array(N);
    let py = cfg.startElevation;
    const runoutGrade = 0.035;
    for (let i = 0; i < N; i++) {
      y[i] = py;
      const g = i < finishCount ? gradeRel[i] * gScale : runoutGrade;
      grade[i] = g;
      py -= g * ds;
    }
    // Ondulaciones suaves (rollers / whoops) proporcionales a la rugosidad
    for (let i = 0; i < N; i++) {
      const s = i * ds;
      const fadeIn = clamp(s / 20, 0, 1);
      y[i] += fadeIn * rough[i] * (0.28 * this.noise(s / 11, 3.7) + 0.1 * this.noise(s / 4.5, 9.1));
    }

    this.x = x; this.y = y; this.z = z; this.theta = theta;
    this.kappa = Float32Array.from(kappa.length === N ? kappa : [...kappa, kappa[kappa.length - 1]]);
    this.halfW = Float32Array.from(halfW);
    this.rough = Float32Array.from(rough);
    this.expL = Float32Array.from(expL);
    this.expR = Float32Array.from(expR);
    this.rockDensity = Float32Array.from(rockD);
    this.grade = grade;
    this.secIdx = Int16Array.from([...secIdx, secIdx[secIdx.length - 1]]);
    this.gradeScale = gScale;

    // Pendiente efectiva por sección (para debug / README)
    this.sectionStats = sections.map((sec, si) => {
      const a = Math.round(sectionStarts[si] / ds);
      const b = si + 1 < sections.length ? Math.round(sectionStarts[si + 1] / ds) : finishCount;
      return {
        name: sec.name,
        length: (b - a) * ds,
        grade: sec.grade * gScale,
        dropM: y[a] - y[Math.min(b, N - 1)],
      };
    });

    this.buildBounds();
    this.buildSpatialHash();
    this.buildCoarseSegments();
  }

  buildBounds() {
    let minX = Infinity, maxX = -Infinity, minZ = Infinity, maxZ = -Infinity;
    for (let i = 0; i < this.count; i++) {
      minX = Math.min(minX, this.x[i]); maxX = Math.max(maxX, this.x[i]);
      minZ = Math.min(minZ, this.z[i]); maxZ = Math.max(maxZ, this.z[i]);
    }
    this.bounds = { minX, maxX, minZ, maxZ };
  }

  buildSpatialHash() {
    const cell = 4;
    const b = this.bounds;
    const ox = b.minX - 20, oz = b.minZ - 20;
    const nx = Math.ceil((b.maxX - b.minX + 40) / cell) + 1;
    const nz = Math.ceil((b.maxZ - b.minZ + 40) / cell) + 1;
    const cells = new Array(nx * nz);
    for (let i = 0; i < this.count; i++) {
      const cx = Math.floor((this.x[i] - ox) / cell);
      const cz = Math.floor((this.z[i] - oz) / cell);
      const k = cz * nx + cx;
      (cells[k] || (cells[k] = [])).push(i);
    }
    this.hash = { cell, ox, oz, nx, nz, cells };
  }

  // Segmentos gruesos (cada 4 m) para la envolvente del cerro
  buildCoarseSegments() {
    const step = 8; // 8 muestras * 0.5 = 4 m
    const segs = [];
    const extra = 12; // extiende el cerro antes de la salida (plataforma de arranque)
    // punto virtual antes del inicio
    const th0 = this.theta[0];
    const pre = {
      x: this.x[0] - Math.sin(th0) * extra,
      z: this.z[0] + Math.cos(th0) * extra,
      y: this.y[0] + 0.3,
    };
    let prev = pre;
    let prevI = 0;
    for (let i = 0; i < this.count; i += step) {
      const cur = { x: this.x[i], z: this.z[i], y: this.y[i] };
      segs.push(this.makeSeg(prev, cur, i === 0 ? 0 : prevI, i));
      prev = cur; prevI = i;
    }
    // extensión más allá del final (el cerro sigue bajando hacia el mar)
    const iL = this.count - 1;
    const thL = this.theta[iL];
    const last = { x: this.x[iL], z: this.z[iL], y: this.y[iL] };
    segs.push(this.makeSeg(prev, last, prevI, iL));
    let p = last;
    for (let k = 1; k <= 12; k++) {
      const n = {
        x: last.x + Math.sin(thL) * 10 * k,
        z: last.z - Math.cos(thL) * 10 * k,
        y: last.y - 10 * k * (0.12 + k * 0.03),
      };
      segs.push(this.makeSeg(p, n, iL, iL));
      p = n;
    }
    this.segs = segs;
  }

  makeSeg(a, b, ia, ib) {
    const dx = b.x - a.x, dz = b.z - a.z;
    const len2 = Math.max(1e-6, dx * dx + dz * dz);
    const len = Math.sqrt(len2);
    return {
      ax: a.x, az: a.z, ay: a.y, bx: b.x, bz: b.z, by: b.y,
      dx, dz, len2,
      rx: -dz / len, rz: dx / len, // derecha: (cosθ, sinθ) == (-dz, dx)/len  con dir=(dx,dz)
      expL: (this.expL[ia] + this.expL[ib]) / 2,
      expR: (this.expR[ia] + this.expR[ib]) / 2,
    };
  }

  /** Muestra interpolada en la distancia s (m) a lo largo del trail. */
  sampleAt(s, out = {}) {
    const f = clamp(s / this.ds, 0, this.count - 1.0001);
    const i = Math.floor(f);
    const t = f - i;
    const j = i + 1;
    out.s = s;
    out.x = lerp(this.x[i], this.x[j], t);
    out.y = lerp(this.y[i], this.y[j], t);
    out.z = lerp(this.z[i], this.z[j], t);
    out.theta = lerp(this.theta[i], this.theta[j], t);
    out.kappa = lerp(this.kappa[i], this.kappa[j], t);
    out.halfW = lerp(this.halfW[i], this.halfW[j], t);
    out.rough = lerp(this.rough[i], this.rough[j], t);
    out.grade = (this.y[i] - this.y[j]) / this.ds; // pendiente real (positivo = baja)
    out.section = this.secIdx[i];
    out.dirX = Math.sin(out.theta);
    out.dirZ = -Math.cos(out.theta);
    out.rightX = Math.cos(out.theta);
    out.rightZ = Math.sin(out.theta);
    return out;
  }

  /**
   * Punto más cercano del eje del trail a (x, z), buscando sólo en un radio ~4 m.
   * Devuelve null si está lejos del trail.
   */
  nearest(px, pz, out = {}) {
    const h = this.hash;
    const cx = Math.floor((px - h.ox) / h.cell);
    const cz = Math.floor((pz - h.oz) / h.cell);
    let best = -1, bestD = Infinity;
    for (let jz = cz - 1; jz <= cz + 1; jz++) {
      if (jz < 0 || jz >= h.nz) continue;
      for (let jx = cx - 1; jx <= cx + 1; jx++) {
        if (jx < 0 || jx >= h.nx) continue;
        const list = h.cells[jz * h.nx + jx];
        if (!list) continue;
        for (let k = 0; k < list.length; k++) {
          const i = list[k];
          const dx = px - this.x[i], dz = pz - this.z[i];
          const d = dx * dx + dz * dz;
          if (d < bestD) { bestD = d; best = i; }
        }
      }
    }
    if (best < 0) return null;
    // refinamiento: proyectar sobre los segmentos vecinos
    let bi = best, bt = 0, bd = bestD;
    for (const [a, b] of [[best - 1, best], [best, best + 1]]) {
      if (a < 0 || b >= this.count) continue;
      const ex = this.x[b] - this.x[a], ez = this.z[b] - this.z[a];
      const l2 = ex * ex + ez * ez;
      let t = ((px - this.x[a]) * ex + (pz - this.z[a]) * ez) / l2;
      t = clamp(t, 0, 1);
      const qx = this.x[a] + ex * t, qz = this.z[a] + ez * t;
      const d = (px - qx) ** 2 + (pz - qz) ** 2;
      if (d <= bd) { bd = d; bi = a; bt = t; }
    }
    const s = (bi + bt) * this.ds;
    const th = lerp(this.theta[bi], this.theta[Math.min(bi + 1, this.count - 1)], bt);
    const cxp = lerp(this.x[bi], this.x[Math.min(bi + 1, this.count - 1)], bt);
    const czp = lerp(this.z[bi], this.z[Math.min(bi + 1, this.count - 1)], bt);
    out.s = s;
    out.o = (px - cxp) * Math.cos(th) + (pz - czp) * Math.sin(th);
    out.d = Math.sqrt(bd);
    out.i = bi;
    return out;
  }

  sectionAt(s) {
    return this.secIdx[clamp(Math.floor(s / this.ds), 0, this.count - 1)];
  }
}
