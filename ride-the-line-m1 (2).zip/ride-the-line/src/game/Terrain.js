import * as THREE from 'three';
import { createNoise2D, fbm, mulberry32, clamp, lerp, smoothstep } from '../utils/noise.js';
import { makeGroundDetailTexture } from '../utils/textures.js';

/**
 * Terreno árido del Morro:
 *  - Un "cerro" que envuelve al trail: el eje del trail es la cresta y el
 *    terreno cae a cada lado (exposición), hasta hundirse en el Pacífico.
 *  - El trail se talla (carve) en ese cerro con un hombro suave.
 *  - Una malla de grilla no uniforme (fina cerca del trail, gruesa lejos)
 *    + una cinta fina alineada al trail para que el borde del sendero sea nítido.
 *  - Rocas instanciadas.
 */
export class Terrain {
  constructor(trail, config, seed) {
    this.trail = trail;
    this.cfg = config;
    this.seed = seed;
    this.noise = createNoise2D(seed * 13 + 1);
    this.noise2 = createNoise2D(seed * 31 + 5);
    this._near = {};
    this._sample = {};

    // Cerros "hito" (silueta inspirada en el Morro Solar, con cruz en la cima)
    const b = trail.bounds;
    this.peaks = [
      // cumbre principal detrás de la salida
      { x: trail.x[0] + 60, z: trail.z[0] + 150, h: config.peakHeight ?? 175, r: 150 },
      // cumbre secundaria a la izquierda, con cruz y antena
      { x: b.minX - 330, z: (b.minZ + b.maxZ) / 2 - 60, h: 135, r: 270, landmark: true },
    ];
  }

  falloff(d) {
    return this.cfg.ridgeFalloff * d + this.cfg.ridgeFalloffQuad * d * d;
  }

  /** Envolvente del cerro (sin tallado del trail). Devuelve [altura, distanciaMínimaAlEje]. */
  envelope(x, z) {
    const segs = this.trail.segs;
    let best = -1e9, minD = 1e9;
    for (let k = 0; k < segs.length; k++) {
      const g = segs[k];
      let t = ((x - g.ax) * g.dx + (z - g.az) * g.dz) / g.len2;
      t = t < 0 ? 0 : t > 1 ? 1 : t;
      const ex = x - (g.ax + g.dx * t);
      const ez = z - (g.az + g.dz * t);
      const d = Math.sqrt(ex * ex + ez * ez);
      if (d < minD) minD = d;
      const side = ex * g.rx + ez * g.rz;
      const expo = side > 0 ? g.expR : g.expL;
      const e = g.ay + (g.by - g.ay) * t - this.falloff(d) * expo;
      if (e > best) best = e;
    }
    return [best, minD];
  }

  baseHeight(x, z) {
    const [env, minD] = this.envelope(x, z);
    const n = this.noise, n2 = this.noise2;
    let h = env;
    // Lomas grandes lejos del trail
    h += fbm(n, x / 70, z / 70, 4) * 16 * smoothstep(10, 90, minD);
    // Quebradas (erosión)
    h -= Math.abs(n2(x / 34, z / 34)) * 7 * smoothstep(12, 70, minD);
    // Relieve rocoso de media escala
    h += fbm(n2, x / 8, z / 8, 3) * (0.35 + 1.2 * smoothstep(2.5, 25, minD));
    h += fbm(n, x / 2.2, z / 2.2, 2) * 0.12 * smoothstep(1, 4, minD);
    // Cumbres hito (smooth max)
    for (const p of this.peaks) {
      const d2 = ((x - p.x) ** 2 + (z - p.z) ** 2) / (p.r * p.r);
      const ph = p.h * Math.exp(-d2 * 1.6) + fbm(n, x / 40, z / 40, 3) * 10 * Math.exp(-d2);
      h = smax(h, ph - 25 * (1 - Math.exp(-d2)), 14);
    }
    return [h, minD];
  }

  /** Altura de la superficie del sendero en coordenadas del trail (s, o). */
  treadHeight(s, o, sample) {
    const u = o / sample.halfW;
    const dish = Math.abs(u) < 1 ? -0.045 * (1 - u * u) : 0;
    const r = sample.rough;
    const bumps =
      r * (0.055 * this.noise(s * 0.45, o * 0.8) + 0.025 * this.noise2(s * 1.7, o * 2.3));
    return sample.y + dish + bumps;
  }

  /**
   * Altura final del terreno en (x,z).
   * info (opcional) recibe: onTrail, d (distancia al eje), o, s, rough.
   */
  heightAt(x, z, info) {
    const [base, minD] = this.baseHeight(x, z);
    const near = this.trail.nearest(x, z, this._near);
    let h = base;
    if (info) { info.onTrail = false; info.d = minD; info.o = 0; info.s = -1; info.rough = 1; info.halfW = 1; }
    if (near) {
      const smp = this.trail.sampleAt(near.s, this._sample);
      const edge = smp.halfW + this.cfg.bankWidth;
      if (near.d < edge) {
        const tread = this.treadHeight(near.s, near.o, smp);
        const t = smoothstep(smp.halfW * 0.8, edge, near.d);
        h = lerp(tread, base, t);
      }
      if (info) {
        info.d = near.d; info.o = near.o; info.s = near.s;
        info.onTrail = near.d <= smp.halfW;
        info.rough = smp.rough; info.halfW = smp.halfW;
      }
    }
    return h;
  }

  // ---------------------------------------------------------------------------
  //  Color (vertex colors). Paleta: beige, arena, marrón, terracota, roca gris.
  // ---------------------------------------------------------------------------
  colorAt(x, z, h, slope, trailD, halfW, out) {
    const n = this.noise, n2 = this.noise2;
    // base arena/beige
    let r = 0.78, g = 0.69, b = 0.56;
    // manchas terracota
    const terra = smoothstep(0.15, 0.6, n(x / 45 + 11, z / 45 - 3));
    r = lerp(r, 0.74, terra * 0.6); g = lerp(g, 0.56, terra * 0.6); b = lerp(b, 0.43, terra * 0.6);
    // zonas de roca suelta (gris-marrón)
    const rocky = clamp(smoothstep(-0.25, 0.55, fbm(n2, x / 16, z / 16, 3)) * 0.8 + slope * 1.4, 0, 1);
    r = lerp(r, 0.55, rocky * 0.75); g = lerp(g, 0.51, rocky * 0.75); b = lerp(b, 0.46, rocky * 0.75);
    // cascajo junto al sendero (como en la referencia: piedra suelta gris a ambos lados)
    const rubbleBand = smoothstep(halfW + 0.15, halfW + 0.9, trailD) * (1 - smoothstep(9, 22, trailD));
    const rubble = Math.max(rubbleBand, rocky * 0.8, 0.35);
    r = lerp(r, 0.6, rubbleBand * 0.55); g = lerp(g, 0.56, rubbleBand * 0.55); b = lerp(b, 0.51, rubbleBand * 0.55);
    // variación fina
    const v = 1 + 0.07 * n(x / 3.1, z / 3.1);
    r *= v; g *= v; b *= v;
    // Sendero: tierra compacta más clara, centro ligeramente más oscuro (huella)
    if (trailD < halfW + 1.2) {
      const w = 1 - smoothstep(halfW * 0.75, halfW + 0.9, trailD);
      const center = 1 - smoothstep(0, halfW * 0.55, trailD);
      let tr = 0.87, tg = 0.76, tb = 0.64;
      tr = lerp(tr, 0.8, center * 0.5); tg = lerp(tg, 0.68, center * 0.5); tb = lerp(tb, 0.56, center * 0.5);
      r = lerp(r, tr, w); g = lerp(g, tg, w); b = lerp(b, tb, w);
      out[3] = lerp(rubble, 0, w);
    } else out[3] = rubble;
    // Orilla / arena húmeda / espuma
    if (h < 3) {
      const wet = 1 - smoothstep(0.3, 3, h);
      r = lerp(r, 0.5, wet * 0.8); g = lerp(g, 0.47, wet * 0.8); b = lerp(b, 0.42, wet * 0.8);
      const foam = 1 - smoothstep(-0.1, 0.5, Math.abs(h - 0.15));
      r = lerp(r, 0.9, foam * 0.7); g = lerp(g, 0.9, foam * 0.7); b = lerp(b, 0.88, foam * 0.7);
    }
    // paleta pensada en sRGB → a lineal (vertex colors se interpretan en lineal)
    out[0] = Math.pow(r, 2.2); out[1] = Math.pow(g, 2.2); out[2] = Math.pow(b, 2.2);
  }

  // ---------------------------------------------------------------------------
  //  Mallas
  // ---------------------------------------------------------------------------
  build(scene) {
    const tex = makeGroundDetailTexture(this.seed);
    this.material = new THREE.MeshStandardMaterial({
      vertexColors: true,
      map: tex,
      roughness: 0.96,
      metalness: 0,
    });
    // Mezcla el detalle a dos escalas para evitar que se note el tiling
    // aRubble: 0 = tierra compacta del sendero (grano fino), 1 = cascajo suelto (alto contraste)
    this.material.onBeforeCompile = (shader) => {
      shader.vertexShader = shader.vertexShader
        .replace('#include <common>', '#include <common>\nattribute float aRubble;\nvarying float vRubble;')
        .replace('#include <begin_vertex>', '#include <begin_vertex>\nvRubble = aRubble;');
      shader.fragmentShader = shader.fragmentShader
        .replace('#include <common>', '#include <common>\nvarying float vRubble;')
        .replace(
          '#include <map_fragment>',
          `
        #ifdef USE_MAP
          vec4 texA = texture2D( map, vMapUv );
          vec4 texC = texture2D( map, vMapUv * 2.3 + vec2(0.11, 0.53) );
          vec4 texB = texture2D( map, vMapUv * 0.173 + vec2(0.37, 0.71) );
          float contrast = mix(0.6, 1.9, vRubble);
          vec3 detail = mix(vec3(0.84), texA.rgb, contrast);
          detail *= mix(vec3(1.0), texC.rgb * 1.18, vRubble * 0.8);
          diffuseColor.rgb *= detail * mix(0.82, 1.18, texB.r);
        #endif
        `,
        );
    };

    const grid = this.buildGrid();
    const ribbon = this.buildRibbon();
    grid.receiveShadow = true;
    ribbon.receiveShadow = true;
    scene.add(grid);
    scene.add(ribbon);
    this.gridMesh = grid;
    this.ribbonMesh = ribbon;

    this.buildRocks(scene);
  }

  axisCoords(min, max, cell, extent, center) {
    const inner = [];
    const n = Math.ceil((max - min) / cell);
    for (let i = 0; i <= n; i++) inner.push(min + (i * (max - min)) / n);
    const lo = [], hi = [];
    let step = cell, p = min;
    while (p > center - extent) { step *= 1.1; p -= step; lo.unshift(p); }
    step = cell; p = max;
    while (p < center + extent) { step *= 1.1; p += step; hi.push(p); }
    return [...lo, ...inner, ...hi];
  }

  buildGrid() {
    const b = this.trail.bounds;
    const m = this.cfg.innerMargin;
    const cell = this.cfg.innerCell;
    const cx = (b.minX + b.maxX) / 2, cz = (b.minZ + b.maxZ) / 2;
    const xs = this.axisCoords(b.minX - m, b.maxX + m, cell, this.cfg.outerExtent, cx);
    const zs = this.axisCoords(b.minZ - m, b.maxZ + m, cell, this.cfg.outerExtent, cz);
    const nx = xs.length, nz = zs.length;
    const count = nx * nz;
    const pos = new Float32Array(count * 3);
    const uv = new Float32Array(count * 2);
    const trailD = new Float32Array(count);
    const halfWs = new Float32Array(count);
    const info = {};
    let k = 0;
    for (let j = 0; j < nz; j++) {
      for (let i = 0; i < nx; i++) {
        const x = xs[i], z = zs[j];
        let h = this.heightAt(x, z, info);
        // bajo el sendero, la grilla se hunde: la cinta fina dibuja el trail
        if (info.s >= 0 && info.d < info.halfW + 0.3) h -= 0.4;
        pos[k * 3] = x; pos[k * 3 + 1] = h; pos[k * 3 + 2] = z;
        uv[k * 2] = x / 3; uv[k * 2 + 1] = z / 3;
        trailD[k] = info.d; halfWs[k] = info.halfW;
        k++;
      }
    }
    const idx = new Uint32Array((nx - 1) * (nz - 1) * 6);
    let q = 0;
    for (let j = 0; j < nz - 1; j++) {
      for (let i = 0; i < nx - 1; i++) {
        const a = j * nx + i, bb = a + 1, c = a + nx, d = c + 1;
        if ((i + j) & 1) { idx.set([a, c, bb, bb, c, d], q); }
        else { idx.set([a, c, d, a, d, bb], q); }
        q += 6;
      }
    }
    const geo = new THREE.BufferGeometry();
    geo.setAttribute('position', new THREE.BufferAttribute(pos, 3));
    geo.setAttribute('uv', new THREE.BufferAttribute(uv, 2));
    geo.setIndex(new THREE.BufferAttribute(idx, 1));
    geo.computeVertexNormals();
    const nrm = geo.getAttribute('normal');
    const col = new Float32Array(count * 3);
    const rub = new Float32Array(count);
    const c3 = [0, 0, 0, 0];
    for (let v = 0; v < count; v++) {
      const slope = 1 - nrm.getY(v);
      this.colorAt(pos[v * 3], pos[v * 3 + 2], pos[v * 3 + 1], slope, trailD[v], halfWs[v], c3);
      col[v * 3] = c3[0]; col[v * 3 + 1] = c3[1]; col[v * 3 + 2] = c3[2];
      rub[v] = c3[3];
    }
    geo.setAttribute('color', new THREE.BufferAttribute(col, 3));
    geo.setAttribute('aRubble', new THREE.BufferAttribute(rub, 1));
    geo.computeBoundingSphere();
    this.gridInfo = { nx, nz, vertices: count };
    return new THREE.Mesh(geo, this.material);
  }

  buildRibbon() {
    const tr = this.trail;
    const extra = this.cfg.bankWidth - 0.1; // cuánto se extiende la cinta fuera del borde
    const cols = 25;
    const rowStep = 0.5;
    const rows = Math.floor(tr.length / rowStep) + 1;
    const pos = new Float32Array(rows * cols * 3);
    const uv = new Float32Array(rows * cols * 2);
    const col = new Float32Array(rows * cols * 3);
    const rub = new Float32Array(rows * cols);
    const smp = {};
    const info = {};
    const c3 = [0, 0, 0, 0];
    for (let r = 0; r < rows; r++) {
      const s = Math.min(r * rowStep, tr.length);
      tr.sampleAt(s, smp);
      const W = smp.halfW + extra;
      for (let c = 0; c < cols; c++) {
        // distribución lateral más densa en los bordes del sendero
        const u = (c / (cols - 1)) * 2 - 1;
        const o = Math.sign(u) * Math.pow(Math.abs(u), 0.85) * W;
        const x = smp.x + smp.rightX * o;
        const z = smp.z + smp.rightZ * o;
        let h = this.heightAt(x, z, info);
        const edge = smoothstep(smp.halfW + extra * 0.45, W, Math.abs(o));
        h += 0.015 - edge * 0.14;
        const k = r * cols + c;
        pos[k * 3] = x; pos[k * 3 + 1] = h; pos[k * 3 + 2] = z;
        uv[k * 2] = x / 3; uv[k * 2 + 1] = z / 3;
        this.colorAt(x, z, h, Math.min(0.3, Math.abs(o) > smp.halfW ? 0.15 : 0.02), Math.abs(o), smp.halfW, c3);
        col[k * 3] = c3[0]; col[k * 3 + 1] = c3[1]; col[k * 3 + 2] = c3[2];
        rub[k] = c3[3];
      }
    }
    const idx = new Uint32Array((rows - 1) * (cols - 1) * 6);
    let q = 0;
    for (let r = 0; r < rows - 1; r++) {
      for (let c = 0; c < cols - 1; c++) {
        const a = r * cols + c, b = a + 1, cc = a + cols, d = cc + 1;
        // orden para que la normal apunte hacia arriba (derecha = +o)
        idx.set([a, b, cc, b, d, cc], q);
        q += 6;
      }
    }
    const geo = new THREE.BufferGeometry();
    geo.setAttribute('position', new THREE.BufferAttribute(pos, 3));
    geo.setAttribute('uv', new THREE.BufferAttribute(uv, 2));
    geo.setAttribute('color', new THREE.BufferAttribute(col, 3));
    geo.setAttribute('aRubble', new THREE.BufferAttribute(rub, 1));
    geo.setIndex(new THREE.BufferAttribute(idx, 1));
    geo.computeVertexNormals();
    // si la normal quedó hacia abajo, invertir el orden
    if (geo.getAttribute('normal').getY(Math.floor(cols / 2)) < 0) {
      for (let i = 0; i < idx.length; i += 3) { const t = idx[i + 1]; idx[i + 1] = idx[i + 2]; idx[i + 2] = t; }
      geo.computeVertexNormals();
    }
    const mesh = new THREE.Mesh(geo, this.material);
    return mesh;
  }

  // ---------------------------------------------------------------------------
  //  Rocas (instancing)
  // ---------------------------------------------------------------------------
  makeRockGeometry(rng, detail) {
    const geo = new THREE.IcosahedronGeometry(1, detail);
    const p = geo.getAttribute('position');
    const nz = createNoise2D(Math.floor(rng() * 1e6));
    const sx = 0.8 + rng() * 0.5, sy = 0.6 + rng() * 0.35, sz = 0.8 + rng() * 0.5;
    for (let i = 0; i < p.count; i++) {
      const x = p.getX(i), y = p.getY(i), z = p.getZ(i);
      const k = 1 + 0.3 * nz(x * 1.3 + y, z * 1.3 - y) + 0.12 * nz(x * 3.1 - z, y * 3.3);
      // base aplanada: las rocas parecen asentadas
      const yy = y < -0.2 ? -0.2 + (y + 0.2) * 0.3 : y;
      p.setXYZ(i, x * k * sx, yy * k * sy, z * k * sz);
    }
    geo.computeVertexNormals();
    return geo;
  }

  buildRocks(scene) {
    const rng = mulberry32(this.seed * 97 + 11);
    const tr = this.trail;
    const geos = [
      this.makeRockGeometry(rng, 0),
      this.makeRockGeometry(rng, 0),
      this.makeRockGeometry(rng, 1),
      this.makeRockGeometry(rng, 1),
    ];
    const palette = [
      [0.44, 0.41, 0.38], [0.5, 0.46, 0.41], [0.4, 0.38, 0.36],
      [0.52, 0.47, 0.41], [0.5, 0.41, 0.35], [0.56, 0.51, 0.45],
    ];
    const near = [[], [], [], []];
    const far = [[], [], [], []];
    const info = {};
    const nearTmp = {};
    const smp = {};
    const density = this.cfg.rockCount;

    const place = (list, x, z, size, sink = 0.35) => {
      const n = tr.nearest(x, z, nearTmp);
      if (n) {
        const hw = tr.sampleAt(n.s, smp).halfW;
        if (n.d < hw + 0.05 && size > 0.09) return; // no rocas grandes sobre el sendero
      }
      const h = this.heightAt(x, z, info);
      // piedras chicas: geometría de 20 triángulos; grandes: 80
      const variant = (size < 0.22 ? 0 : 2) + (rng() < 0.5 ? 0 : 1);
      list[variant].push({
        x, y: h - size * sink, z, size,
        ry: rng() * Math.PI * 2, rx: (rng() - 0.5) * 0.4, rz: (rng() - 0.5) * 0.4,
        c: palette[Math.floor(rng() * palette.length)], v: 0.85 + rng() * 0.3,
      });
    };

    // Rocas a lo largo del trail
    for (let s = 0; s < tr.length; s += 0.5) {
      tr.sampleAt(s, smp);
      const dens = smp.rough * 0 + tr.rockDensity[Math.floor(s / tr.ds)] * density;
      for (const side of [-1, 1]) {
        // línea de borde: piedras que "delimitan" el sendero
        const nEdge = Math.floor(1.3 * dens + rng());
        for (let i = 0; i < nEdge; i++) {
          const o = side * (smp.halfW + 0.1 + Math.pow(rng(), 1.6) * 1.2);
          const size = 0.05 + Math.pow(rng(), 2.4) * 0.24 * Math.min(dens, 1.2);
          place(near, smp.x + smp.rightX * o + (rng() - 0.5) * 0.5, smp.z + smp.rightZ * o + (rng() - 0.5) * 0.5, size);
        }
        // campo de rocas sueltas a los lados
        const nField = Math.floor(4.5 * dens + rng());
        for (let i = 0; i < nField; i++) {
          const o = side * (smp.halfW + 0.8 + Math.pow(rng(), 1.9) * 16);
          const big = rng() < 0.05 && Math.abs(o) > smp.halfW + 3;
          const size = big ? 0.45 + rng() * 0.5 : 0.07 + Math.pow(rng(), 2.4) * 0.38;
          const list = Math.abs(o) < 8 ? near : far;
          place(list, smp.x + smp.rightX * o + (rng() - 0.5) * 1.5, smp.z + smp.rightZ * o + (rng() - 0.5) * 1.5, size);
        }
      }
      // piedritas incrustadas en el sendero (sólo visual en este milestone)
      if (rng() < 0.35 * smp.rough * density) {
        const o = (rng() * 2 - 1) * smp.halfW * 0.9;
        const size = 0.035 + rng() * 0.05;
        place(near, smp.x + smp.rightX * o, smp.z + smp.rightZ * o, size, 0.55);
      }
    }
    // Pedrones dispersos en las laderas
    const b = tr.bounds;
    const m = this.cfg.innerMargin;
    const farCount = Math.floor(3500 * density);
    for (let i = 0; i < farCount; i++) {
      const x = lerp(b.minX - m, b.maxX + m, rng());
      const z = lerp(b.minZ - m, b.maxZ + m, rng());
      const size = 0.3 + Math.pow(rng(), 2.5) * 1.4;
      place(far, x, z, size, 0.45);
    }

    const mat = new THREE.MeshStandardMaterial({ roughness: 0.92, metalness: 0, flatShading: true });
    const dummy = new THREE.Object3D();
    const color = new THREE.Color();
    const make = (lists, cast) => {
      lists.forEach((list, vi) => {
        if (!list.length) return;
        const im = new THREE.InstancedMesh(geos[vi], mat, list.length);
        list.forEach((r, k) => {
          dummy.position.set(r.x, r.y, r.z);
          dummy.rotation.set(r.rx, r.ry, r.rz);
          dummy.scale.setScalar(r.size);
          dummy.updateMatrix();
          im.setMatrixAt(k, dummy.matrix);
          color.setRGB(r.c[0] * r.v, r.c[1] * r.v, r.c[2] * r.v, THREE.SRGBColorSpace);
          im.setColorAt(k, color);
        });
        im.castShadow = cast;
        im.receiveShadow = true;
        im.instanceMatrix.needsUpdate = true;
        im.computeBoundingSphere();
        scene.add(im);
      });
    };
    make(near, true);
    make(far, false);
    this.rockCounts = {
      near: near.reduce((a, l) => a + l.length, 0),
      far: far.reduce((a, l) => a + l.length, 0),
    };
  }
}

function smax(a, b, k) {
  const h = clamp(0.5 + (0.5 * (b - a)) / k, 0, 1);
  return lerp(a, b, h) + k * h * (1 - h);
}
