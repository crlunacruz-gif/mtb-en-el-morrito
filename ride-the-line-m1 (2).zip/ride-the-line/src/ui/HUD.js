/**
 * HUD minimalista. En Milestone 1 sólo SPEED (FLOW/CONTROL/SEND llegan con el scoring).
 * Incluye overlays de inicio/fin y un panel de debug (tecla G).
 */
export class HUD {
  constructor(root) {
    this.root = root;
    root.innerHTML = `
      <div class="hud-speed"><span class="hud-speed-val">0</span><span class="hud-speed-unit">km/h</span></div>
      <div class="hud-progress"><div class="hud-progress-bar"></div></div>
      <div class="hud-section"></div>
      <div class="overlay overlay-intro">
        <div class="overlay-inner">
          <div class="kicker">Morro Solar · Chorrillos · Lima</div>
          <h1>RIDE THE LINE</h1>
          <p class="loading">Generando el cerro…</p>
          <button class="btn-start" hidden>DROP IN</button>
          <div class="controls">
            <span><b>A</b>/<b>D</b> · <b>←</b>/<b>→</b> dirección</span>
            <span><b>S</b> freno</span>
            <span><b>R</b> reiniciar</span>
            <span><b>M</b> sonido</span>
            <span><b>G</b> ajustes</span>
          </div>
        </div>
      </div>
      <div class="overlay overlay-finish" hidden>
        <div class="overlay-inner">
          <div class="kicker">Fin de la bajada</div>
          <h2 class="finish-time">00.0 s</h2>
          <p class="finish-stats"></p>
          <button class="btn-again">RIDE AGAIN</button>
        </div>
      </div>
      <div class="debug" hidden></div>
    `;
    this.speedEl = root.querySelector('.hud-speed-val');
    this.progressEl = root.querySelector('.hud-progress-bar');
    this.sectionEl = root.querySelector('.hud-section');
    this.intro = root.querySelector('.overlay-intro');
    this.finish = root.querySelector('.overlay-finish');
    this.startBtn = root.querySelector('.btn-start');
    this.againBtn = root.querySelector('.btn-again');
    this.loadingEl = root.querySelector('.loading');
    this.debugEl = root.querySelector('.debug');
    this.lastSection = -1;
    this.sectionTimer = 0;
  }

  setReady() {
    this.loadingEl.hidden = true;
    this.startBtn.hidden = false;
    this.startBtn.focus();
  }

  showIntro(v) { this.intro.hidden = !v; }

  showFinish(time, maxKmh, avgKmh, drop) {
    this.finish.hidden = false;
    this.finish.querySelector('.finish-time').textContent = `${time.toFixed(1)} s`;
    this.finish.querySelector('.finish-stats').innerHTML =
      `Vel. máx <b>${maxKmh.toFixed(0)} km/h</b> · Promedio <b>${avgKmh.toFixed(0)} km/h</b> · Desnivel <b>${drop.toFixed(0)} m</b>`;
  }

  hideFinish() { this.finish.hidden = true; }

  update(dt, bike, trail) {
    this.speedEl.textContent = Math.round(bike.speedKmh);
    this.progressEl.style.transform = `scaleX(${Math.min(1, bike.s / trail.finishS)})`;
    // nombre de sección: aparece discretamente al entrar y se desvanece
    if (bike.running && bike.section !== this.lastSection) {
      this.lastSection = bike.section;
      this.sectionEl.textContent = trail.sections[bike.section].name.toUpperCase();
      this.sectionEl.classList.remove('show');
      void this.sectionEl.offsetWidth;
      this.sectionEl.classList.add('show');
    }
  }

  toggleDebug() { this.debugEl.hidden = !this.debugEl.hidden; return !this.debugEl.hidden; }

  updateDebug(lines) {
    if (this.debugEl.hidden) return;
    this.debugEl.textContent = lines.join('\n');
  }
}
